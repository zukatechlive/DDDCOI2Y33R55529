local Ast = require("ZukaTech.ast")
local utils = require("ZukaTech.util")

-- ── Charset ───────────────────────────────────────────────────────────────
local charset = utils.chararray("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890")
local charsetLen = #charset -- Cache length to avoid recomputing each call

-- ── Random string ─────────────────────────────────────────────────────────
-- Iterative approach (avoids stack overflow on large lengths)
local function randomString(wordsOrLen)
	-- Word list mode: pick a random word from the table
	if type(wordsOrLen) == "table" then
		return wordsOrLen[math.random(1, #wordsOrLen)]
	end

	local len = wordsOrLen or math.random(2, 15)

	-- Build string iteratively instead of recursively
	local parts = {}
	for i = 1, len do
		parts[i] = charset[math.random(1, charsetLen)]
	end

	return table.concat(parts)
end

-- ── Random string AST node ────────────────────────────────────────────────
local function randomStringNode(wordsOrLen)
	return Ast.StringExpression(randomString(wordsOrLen))
end

-- ── Unique string (no duplicates within a session) ────────────────────────
local usedStrings = {}

local function uniqueRandomString(len)
	local str
	local attempts = 0
	repeat
		str = randomString(len)
		attempts = attempts + 1
		if attempts > 1000 then
			-- Fallback: append a counter to guarantee uniqueness
			str = str .. tostring(#usedStrings)
			break
		end
	until not usedStrings[str]
	usedStrings[str] = true
	return str
end

local function resetUsed()
	usedStrings = {}
end

return {
	randomString     = randomString,
	randomStringNode = randomStringNode,
	uniqueRandomString = uniqueRandomString,
	resetUsed        = resetUsed,
}