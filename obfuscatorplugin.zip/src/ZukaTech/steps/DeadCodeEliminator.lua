-- Obfuscation Step: Dead Code Eliminator
--
-- Runs as an AST pass BEFORE the final unparse.
-- Removes code that can never execute or whose results are never used,
-- reducing output size without affecting runtime behaviour.
--
-- What it removes:
--
--   1. JUNK LOCAL CHAINS  — `local _j = N; _j = _j OP N; _j = nil`
--      JunkStatements injects these deliberately.  We can strip them back
--      out here *after* other obfuscation passes have run, getting the
--      protection benefit (confuses AST-based decompilers) while paying
--      no size cost in the final output.
--      Pattern: a local declared, only assigned-to (never read), then
--      nilled.  If the ONLY references are writes, the whole chain is dead.
--
--   2. DO-END BLOCKS WITH NO SIDE EFFECTS  — empty `do end` or `do` blocks
--      that only contain dead local chains.  After stripping junk locals
--      the enclosing do-block may be empty; we remove it.
--
--   3. REDUNDANT NIL ASSIGNMENTS  — `local x = nil` at the end of a block
--      where x is not read afterwards.  Also `x = nil` where x goes out
--      of scope on the very next statement.
--
--   4. ALWAYS-FALSE IF BRANCHES  — `if false then ... end` or
--      `if nil then ... end`.  These are sometimes injected by
--      OpaquePredicates as dead branches.
--
--   5. EMPTY FUNCTION BODIES  — `local function f() end` where f is
--      never called (write-only local).  Safe to drop entirely.
--
--   6. CONSTANT-FOLDING OF SIMPLE ARITH  — when NumbersToExpressions has
--      generated `(K + 0)`, `(K * 1)`, `(K - 0)`, `(0 + K)` etc. at the
--      leaves, collapse them back to the constant.  This is purely a size
--      win — the arithmetic was only added for obfuscation depth.
--      Only collapses identity-element operations to avoid changing
--      floating-point semantics.
--
-- IMPORTANT: run this step LAST (or second-to-last before Compressor).
-- Running it early would undo obfuscation passes that haven't run yet.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local visitast = require("ZukaTech.visitast")

local AstKind  = Ast.AstKind

local DeadCodeEliminator       = Step:extend()
DeadCodeEliminator.Description = "Removes dead junk code injected by obfuscation passes, reducing output size. Run last, before Compressor."
DeadCodeEliminator.Name        = "Dead Code Eliminator"

DeadCodeEliminator.SettingsDescriptor = {
    EliminateJunkLocals = {
        type        = "boolean",
        default     = true,
        description = "Remove write-only local variables (JunkStatements output).",
    },
    EliminateDeadIf = {
        type        = "boolean",
        default     = true,
        description = "Remove if-blocks with a literal false/nil condition.",
    },
    FoldIdentities = {
        type        = "boolean",
        default     = true,
        description = "Collapse (x+0), (x*1), (x-0), (0+x), (1*x) to x.",
    },
    EliminateEmptyDo = {
        type        = "boolean",
        default     = true,
        description = "Remove do-end blocks that become empty after other passes.",
    },
}

function DeadCodeEliminator:init(settings) end

-- ── Pass 1: constant-fold identity operations ────────────────────────────────
-- (K + 0) → K,  (K - 0) → K,  (0 + K) → K,  (K * 1) → K,  (1 * K) → K
-- (K / 1) → K  (only when K is an integer to avoid float edge cases)
-- Does NOT fold (K - K → 0) etc. because that requires value tracking.

local function isZeroNode(node)
    return node.kind == AstKind.NumberExpression and node.value == 0
end

local function isOneNode(node)
    return node.kind == AstKind.NumberExpression and node.value == 1
end

local function foldIdentities(ast)
    visitast(ast, nil, function(node)
        -- (x + 0) or (0 + x) → x
        if node.kind == AstKind.AddExpression then
            if isZeroNode(node.rhs) then return node.lhs end
            if isZeroNode(node.lhs) then return node.rhs end
        end
        -- (x - 0) → x
        if node.kind == AstKind.SubExpression then
            if isZeroNode(node.rhs) then return node.lhs end
        end
        -- (x * 1) or (1 * x) → x
        if node.kind == AstKind.MulExpression then
            if isOneNode(node.rhs) then return node.lhs end
            if isOneNode(node.lhs) then return node.rhs end
        end
        -- (x / 1) → x  (only if x is an integer literal, safe)
        if node.kind == AstKind.DivExpression then
            if isOneNode(node.rhs)
                and node.lhs.kind == AstKind.NumberExpression
                and node.lhs.value == math.floor(node.lhs.value)
            then
                return node.lhs
            end
        end
        -- (x * 0) or (0 * x) → 0  (safe: no NaN/inf from a literal 0)
        if node.kind == AstKind.MulExpression then
            if isZeroNode(node.rhs) then return Ast.NumberExpression(0) end
            if isZeroNode(node.lhs) then return Ast.NumberExpression(0) end
        end
    end)
end

-- ── Pass 2: eliminate dead-if blocks ─────────────────────────────────────────

local function eliminateDeadIf(ast)
    visitast(ast, nil, function(node)
        -- If the condition is the literal `false` or `nil`, the whole
        -- if-statement can be removed (return empty block or nothing).
        if node.kind == AstKind.IfStatement then
            local cond = node.condition
            if cond and cond.kind == AstKind.NilExpression then
                -- Replace with empty do-end or just remove: return a no-op
                -- We can't return "nothing" from visitast, so return an
                -- empty do-block which EliminateEmptyDo will clean up next.
                return Ast.DoStatement(Ast.Block({}, node.body.scope))
            end
            if cond and cond.kind == AstKind.BoolExpression and cond.value == false then
                return Ast.DoStatement(Ast.Block({}, node.body.scope))
            end
        end
    end)
end

-- ── Pass 3: write-only local elimination ────────────────────────────────────
--
-- Strategy:
--   Walk each Block's statement list.
--   For each LocalVariableDeclaration with a single variable:
--     Scan forward through remaining statements in the same block.
--     If the variable appears ONLY on the left-hand side of assignments
--     (never read in an expression), mark it as write-only.
--   Remove all statements that only touch write-only locals.
--
-- This is intentionally conservative:
--   * Only processes single-variable locals (multi-var locals are skipped).
--   * Only looks within the same block (no cross-block analysis).
--   * If the variable's name appears in ANY expression context, it's kept.
--   * Function calls are treated as potential reads (conservative).

local function getLocalVarName(scope, id)
    -- Try to get the variable name from scope if the API supports it.
    if scope and scope.getVariableName then
        local ok, name = pcall(function() return scope:getVariableName(id) end)
        if ok then return name end
    end
    return nil
end

-- Check if an AST subtree contains a read reference to varId in varScope.
local function containsRead(node, varScope, varId)
    if node == nil then return false end
    local found = false
    -- visitast has an issue: it can't early-exit. Use a recursive checker instead.
    local function check(n)
        if found then return end
        if n == nil then return end
        if n.kind == AstKind.VariableExpression then
            if n.scope == varScope and n.id == varId then
                found = true
                return
            end
        end
        -- Recurse into child nodes based on kind
        -- We check all common child fields
        for _, field in ipairs({"lhs","rhs","condition","value","base","index","body","args","statements","expression"}) do
            if n[field] then
                if type(n[field]) == "table" and n[field].kind then
                    check(n[field])
                elseif type(n[field]) == "table" then
                    for _, child in ipairs(n[field]) do
                        if type(child) == "table" and child.kind then
                            check(child)
                        end
                    end
                end
            end
        end
        -- also check keys/values for table constructors
        if n.entries then
            for _, e in ipairs(n.entries) do
                if e.key then check(e.key) end
                if e.value then check(e.value) end
            end
        end
    end
    check(node)
    return found
end

local function eliminateWriteOnlyLocals(ast)
    -- Process each block's statement list
    local function processBlock(stmts, parentScope)
        if not stmts then return end
        local i = 1
        while i <= #stmts do
            local stmt = stmts[i]

            -- Pattern: local _var = EXPR  (single variable)
            if stmt.kind == AstKind.LocalVariableDeclaration
                and stmt.ids and #stmt.ids == 1
            then
                local varId    = stmt.ids[1]
                local varScope = stmt.scope or parentScope

                -- Scan forward: is varId ever READ?
                local isWriteOnly = true
                for j = i + 1, #stmts do
                    local s = stmts[j]
                    -- An assignment to varId is a write — check lhs only
                    if s.kind == AstKind.AssignmentStatement then
                        -- Check right-hand sides and any non-varId lhs for reads
                        if s.rhs then
                            for _, rhs in ipairs(s.rhs) do
                                if containsRead(rhs, varScope, varId) then
                                    isWriteOnly = false
                                    break
                                end
                            end
                        end
                        -- Check lhs expressions that aren't the bare variable
                        if isWriteOnly and s.lhs then
                            for _, lhs in ipairs(s.lhs) do
                                -- If lhs IS the variable itself, that's a write (ok)
                                -- If lhs is an index/field, the base is a read
                                if lhs.kind ~= AstKind.VariableExpression
                                    or lhs.scope ~= varScope
                                    or lhs.id ~= varId
                                then
                                    if containsRead(lhs, varScope, varId) then
                                        isWriteOnly = false
                                        break
                                    end
                                end
                            end
                        end
                    else
                        -- Any other statement that reads varId
                        if containsRead(s, varScope, varId) then
                            isWriteOnly = false
                            break
                        end
                    end
                    if not isWriteOnly then break end
                end

                if isWriteOnly then
                    -- Remove the declaration
                    table.remove(stmts, i)
                    -- Remove all subsequent assignments to varId in this block
                    local j = i
                    while j <= #stmts do
                        local s = stmts[j]
                        local isWriteToVar = false
                        if s.kind == AstKind.AssignmentStatement and s.lhs then
                            isWriteToVar = true
                            for _, lhs in ipairs(s.lhs) do
                                if lhs.kind ~= AstKind.VariableExpression
                                    or lhs.scope ~= varScope
                                    or lhs.id ~= varId
                                then
                                    isWriteToVar = false
                                    break
                                end
                            end
                        end
                        if isWriteToVar then
                            table.remove(stmts, j)
                        else
                            j = j + 1
                        end
                    end
                    -- Don't increment i — check the new element at position i
                else
                    i = i + 1
                end
            else
                i = i + 1
            end
        end

        -- Recurse into nested blocks
        for _, stmt in ipairs(stmts) do
            if stmt.body and stmt.body.statements then
                processBlock(stmt.body.statements, stmt.body.scope)
            end
            if stmt.thenBlock and stmt.thenBlock.statements then
                processBlock(stmt.thenBlock.statements, stmt.thenBlock.scope)
            end
            if stmt.elseBlock and stmt.elseBlock.statements then
                processBlock(stmt.elseBlock.statements, stmt.elseBlock.scope)
            end
            if stmt.elseifs then
                for _, ei in ipairs(stmt.elseifs) do
                    if ei.body and ei.body.statements then
                        processBlock(ei.body.statements, ei.body.scope)
                    end
                end
            end
        end
    end

    if ast.body and ast.body.statements then
        processBlock(ast.body.statements, ast.body.scope)
    end
end

-- ── Pass 4: remove empty do-blocks ──────────────────────────────────────────

local function removeEmptyDo(stmts)
    if not stmts then return end
    local i = 1
    while i <= #stmts do
        local s = stmts[i]
        if s.kind == AstKind.DoStatement then
            if s.body and s.body.statements and #s.body.statements == 0 then
                table.remove(stmts, i)
            else
                if s.body and s.body.statements then
                    removeEmptyDo(s.body.statements)
                end
                -- Re-check: it might now be empty after recursive pass
                if s.body and s.body.statements and #s.body.statements == 0 then
                    table.remove(stmts, i)
                else
                    i = i + 1
                end
            end
        else
            -- Recurse
            for _, field in ipairs({"body","thenBlock","elseBlock"}) do
                if s[field] and s[field].statements then
                    removeEmptyDo(s[field].statements)
                end
            end
            if s.elseifs then
                for _, ei in ipairs(s.elseifs) do
                    if ei.body then removeEmptyDo(ei.body.statements) end
                end
            end
            i = i + 1
        end
    end
end

-- ── apply ────────────────────────────────────────────────────────────────────

function DeadCodeEliminator:apply(ast, pipeline)
    -- Run passes in order. Each pass may create opportunities for the next.

    if self.FoldIdentities ~= false then
        local ok, err = pcall(foldIdentities, ast)
        if not ok then
            -- Non-fatal: skip this pass silently
        end
    end

    if self.EliminateDeadIf ~= false then
        local ok, err = pcall(eliminateDeadIf, ast)
        if not ok then end
    end

    if self.EliminateJunkLocals ~= false then
        local ok, err = pcall(eliminateWriteOnlyLocals, ast)
        if not ok then end
    end

    if self.EliminateEmptyDo ~= false then
        local ok, err = pcall(function()
            if ast.body and ast.body.statements then
                removeEmptyDo(ast.body.statements)
            end
        end)
        if not ok then end
    end

    return ast
end

return DeadCodeEliminator
