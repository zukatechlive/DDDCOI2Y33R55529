-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- steps/VmifyLegacy.lua
--
-- Obfuscation step that compiles the AST through the Prometheus-style
-- stack-based VM (push/pop model) rather than ZukaTech's native
-- register-based VM.  The two backends are architecturally independent
-- and produce completely different output fingerprints, giving pipeline
-- authors a second distinct VM to choose from.
--
-- This step is a drop-in replacement for Vmify / VmifyBC — it consumes
-- a parsed AST and returns a new AST whose body is the self-contained
-- legacy VM source string, ready for the unparser.

local Step     = require("ZukaTech.step");
local Compiler = require("ZukaTech.legacy.compiler");
local logger   = require("logger");

local VmifyLegacy = Step:extend();
VmifyLegacy.Name        = "VmifyLegacy";
VmifyLegacy.Description =
    "Compiles your script to the Prometheus-style stack-based VM bytecode. " ..
    "Produces a fundamentally different VM fingerprint from Vmify / VmifyBC. " ..
    "Compatible with the full ZukaTech pipeline — use in place of Vmify or " ..
    "VmifyBC when a stack-model VM is preferred.";

-- ── Settings ─────────────────────────────────────────────────────────────────

VmifyLegacy.SettingsDescriptor = {
    -- Reserved for future options (e.g. encoding, shuffle constants).
    -- Keeping the descriptor table present so Step:new() validation is happy.
};

-- ── Lifecycle ─────────────────────────────────────────────────────────────────

function VmifyLegacy:init()
    -- Nothing to initialise for the base configuration.
end

-- ── Pipeline entry-point ──────────────────────────────────────────────────────

function VmifyLegacy:apply(ast, pipeline)
    logger:info("[VmifyLegacy] Compiling AST through legacy stack-based VM …");

    local compiler = Compiler:new();

    -- compile() returns a new AST whose body contains the VM source.
    local newAst = compiler:compile(ast);

    logger:info("[VmifyLegacy] Compilation complete.");
    return newAst;
end

return VmifyLegacy;
