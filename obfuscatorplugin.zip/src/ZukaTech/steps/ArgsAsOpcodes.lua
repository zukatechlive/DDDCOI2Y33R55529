-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- steps/ArgsAsOpcodes.lua
--
-- Hoists top-level VM variable initialisations into an outer IIFE's
-- argument list, styled after 77fuscator's args-as-dispatch-table trick.
--
-- Before:
--   local strchar, bytes, bxor, floorfunc, ldexpfunc;
--   strchar   = string.char;
--   floorfunc = math.floor;
--   ldexpfunc = math.ldexp;
--   bxor      = nil;
--   bytes     = "...blob...";
--   ... <vm body> ...
--   return main();
--
-- After:
--   return (function(_a, _b, _c, _d, _e, ...)
--     local strchar, floorfunc, ldexpfunc, bxor, bytes;
--     strchar   = _a;
--     floorfunc = _b;
--     ldexpfunc = _c;
--     bxor      = _d;
--     bytes     = _e;
--     ... <vm body> ...
--     return main();
--   end)(string.char, math.floor, math.ldexp, nil, "...blob...", ...)
--
-- The call site shows the actual values; the function body shows only
-- opaque parameter names.  A static analyser must trace the call to
-- know what `strchar` really is — it can't read it off the body alone.
-- Combined with BootstrapObfuscator the body becomes a state machine
-- whose states receive anonymous parameters. Very close to 77fuscator.
--
-- Only "simple" RHS expressions are hoisted:
--   • StringExpression  (the bytecode blob)
--   • NumberExpression  (constants)
--   • NilExpression     (bxor placeholder)
--   • IndexExpression   whose base is a global (string.char, math.floor…)
--   • VariableExpression that resolves to a global  (getfenv, etc.)
--   • BooleanExpression
-- Everything else stays in-place.

local Step     = require("ZukaTech.step");
local Ast      = require("ZukaTech.ast");
local Scope    = require("ZukaTech.scope");
local logger   = require("logger");

local AstKind = Ast.AstKind;

local ArgsAsOpcodes = Step:extend();
ArgsAsOpcodes.Name        = "ArgsAsOpcodes";
ArgsAsOpcodes.Description =
    "Hoists simple top-level VM variable initialisations into an outer " ..
    "IIFE argument list (77fuscator style). The body receives anonymous " ..
    "parameters; the call site passes the real values.";

ArgsAsOpcodes.SettingsDescriptor = {
    -- Shuffle the order of hoisted args so every compile looks different.
    ShuffleArgs = {
        type    = "boolean";
        default = true;
    };
    -- Also pass vararg (...) through so the outer script's vararg is preserved.
    PassVararg = {
        type    = "boolean";
        default = true;
    };
};

-- ── Helpers ───────────────────────────────────────────────────────────────────

local function isSimpleExpr(node)
    if not node then return false end;
    local k = node.kind;
    if k == AstKind.StringExpression  then return true end;
    if k == AstKind.NumberExpression  then return true end;
    if k == AstKind.NilExpression     then return true end;
    if k == AstKind.BooleanExpression then return true end;
    -- IndexExpression: string.char, math.floor, table.concat, etc.
    if k == AstKind.IndexExpression then
        local base = node.base;
        if base and base.kind == AstKind.VariableExpression then
            if base.scope and base.scope.isGlobal then return true end;
        end
        return false;
    end
    -- VariableExpression resolving to a global (getfenv, unpack, etc.)
    if k == AstKind.VariableExpression then
        if node.scope and node.scope.isGlobal then return true end;
        return false;
    end
    -- OrExpression used for polyfills: (table.unpack or unpack)
    if k == AstKind.OrExpression then
        return isSimpleExpr(node.lhs) and isSimpleExpr(node.rhs);
    end
    -- AndExpression: bit32 and bit32.bxor
    if k == AstKind.AndExpression then
        return isSimpleExpr(node.lhs) and isSimpleExpr(node.rhs);
    end
    return false;
end

-- ── Step lifecycle ────────────────────────────────────────────────────────────

function ArgsAsOpcodes:init() end

-- ── Apply ─────────────────────────────────────────────────────────────────────

function ArgsAsOpcodes:apply(ast, pipeline)
    local shuffle   = self.ShuffleArgs ~= false;
    local passVararg = self.PassVararg ~= false;

    local stmts     = ast.body.statements;
    local bodyScope = ast.body.scope;

    -- ── Pass 1: collect hoist candidates ────────────────────────────────────
    -- We look for AssignmentStatements at the top level whose:
    --   LHS is a single AssignmentVariable (in bodyScope, not global)
    --   RHS is a single simple expression

    local hoistable = {};   -- { stmtIndex, varId, rhs }
    local hoistSet  = {};   -- stmtIndex -> true

    for i, s in ipairs(stmts) do
        if s.kind == AstKind.AssignmentStatement
        and #s.lhs == 1 and #s.rhs == 1
        and s.lhs[1].kind == AstKind.AssignmentVariable
        and not s.lhs[1].scope.isGlobal
        and isSimpleExpr(s.rhs[1]) then
            table.insert(hoistable, { idx = i, varId = s.lhs[1].id, rhs = s.rhs[1] });
            hoistSet[i] = true;
        end
    end

    if #hoistable == 0 then
        logger:warn("[ArgsAsOpcodes] No hoist candidates found, skipping.");
        return;
    end

    -- Optionally shuffle so arg order changes every compile
    if shuffle then
        for i = #hoistable, 2, -1 do
            local j = math.random(1, i);
            hoistable[i], hoistable[j] = hoistable[j], hoistable[i];
        end
    end

    -- ── Pass 2: build outer IIFE ─────────────────────────────────────────────
    -- New scope hierarchy:
    --   ast.globalScope
    --     outerScope   ← the IIFE's function scope (holds the params)
    --       bodyScope  ← existing body scope (reparented)

    local outerScope = Scope:new(ast.globalScope);
    bodyScope:setParent(outerScope);

    -- Add one parameter per hoisted variable
    -- We map varId (in bodyScope) → paramId (in outerScope)
    local paramIds  = {};   -- ordered list of outerScope param ids
    local varToParam = {}; -- bodyScope varId → outerScope paramId

    for _, h in ipairs(hoistable) do
        local pid = outerScope:addVariable();
        table.insert(paramIds, pid);
        varToParam[h.varId] = pid;
    end

    -- Vararg parameter at end
    local paramExprs = {};
    for _, pid in ipairs(paramIds) do
        table.insert(paramExprs, Ast.VariableExpression(outerScope, pid));
    end
    if passVararg then
        table.insert(paramExprs, Ast.VarargExpression());
    end

    -- ── Pass 3: rewrite body ─────────────────────────────────────────────────
    -- Replace each hoisted AssignmentStatement with an assignment from param:
    --   strchar = _a;   →   strchar = <paramId>;
    -- The variable declaration `local strchar, ...` is kept as-is because
    -- it's a LocalVariableDeclaration (separate statement) — we just redirect
    -- the value source.

    local newStmts = {};
    for i, s in ipairs(stmts) do
        if hoistSet[i] then
            -- Find which hoistable entry this is
            local varId = s.lhs[1].id;
            local pid   = varToParam[varId];
            if pid then
                -- Replace RHS with the parameter variable
                local newRhs = Ast.VariableExpression(outerScope, pid);
                outerScope:addReferenceToHigherScope(outerScope, pid);
                local newAssign = Ast.AssignmentStatement(
                    { Ast.AssignmentVariable(bodyScope, varId) },
                    { newRhs }
                );
                table.insert(newStmts, newAssign);
            else
                table.insert(newStmts, s);
            end
        else
            table.insert(newStmts, s);
        end
    end

    -- ── Pass 4: build call-site arg list ────────────────────────────────────
    -- The args match the shuffled hoistable order
    local callArgs = {};
    for _, h in ipairs(hoistable) do
        table.insert(callArgs, h.rhs);
    end
    if passVararg then
        table.insert(callArgs, Ast.VarargExpression());
    end

    -- ── Pass 5: wrap body in IIFE and replace ast.body ──────────────────────
    local innerBlock = Ast.Block(newStmts, bodyScope);
    local iife = Ast.FunctionLiteralExpression(paramExprs, innerBlock);
    local call = Ast.FunctionCallExpression(iife, callArgs);
    local retStmt = Ast.ReturnStatement({ call });

    local wrapperScope = Scope:new(ast.globalScope);
    outerScope:setParent(wrapperScope);

    ast.body = Ast.Block({ retStmt }, wrapperScope);

    logger:info(string.format(
        "[ArgsAsOpcodes] Hoisted %d initialisations into IIFE args.",
        #hoistable));
end

return ArgsAsOpcodes;
