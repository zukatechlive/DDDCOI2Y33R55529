-- namegenerators/byteaddr.lua
-- ByteAddr — by ZukaTech
--
-- Names styled after raw memory addresses, compiler temporaries,
-- and register dumps. The output looks like disassembled binary,
-- not human-written code at all.
--
-- Visually:  _t00_ff3, _r1_a9c, _sp_002b, _bp_1f
--
-- Style families:
--   1. Register-style:   _rN_HHHH  (r0–r15, like CPU regs)
--   2. Stack-style:      _sp_HHHH / _bp_HHHH  (stack/base pointer look)
--   3. Temp-style:       _tNN_HHH  (compiler temporaries: t00, t01...)
--   4. Offset-style:     _oHHHH    (raw offset, shortest)
--
-- All valid Lua 5.1 identifiers. Completely alien to human variable names.

local util  = require("ZukaTech.util")
local bit32 = require("ZukaTech.bit").bit32

local HEX = {"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"}

local REGS  = {"r0","r1","r2","r3","r4","r5","r6","r7",
               "r8","r9","r10","r11","r12","r13","r14","r15"}
local STACK = {"sp","bp","fp","ip"}
local TEMPS = {}
for i = 0, 15 do TEMPS[#TEMPS+1] = string.format("t%02d", i) end

local seed  = 0
local regOrder  = {}
local tempOrder = {}

-- Populate orders at load time so generateName is safe before prepare() fires.
-- prepare() will shuffle these again with a fresh seed when it runs.
for i = 1, #REGS  do regOrder[i]  = i end
for i = 1, #TEMPS do tempOrder[i] = i end

local function prng(n)
    n = bit32.band(n, 0xFFFFFFFF)
    n = bit32.bxor(n, bit32.lshift(n, 13))
    n = bit32.bxor(n, bit32.rshift(n, 7))
    n = bit32.bxor(n, bit32.lshift(n, 17))
    return bit32.band(n * 1664525 + seed, 0xFFFFFFFF)
end

local function toHex(val, digits)
    local s = ""
    for i = 1, digits do
        s = HEX[(val % 16) + 1] .. s
        val = math.floor(val / 16)
    end
    return s
end

local function generateName(id, scope)
    local family = prng(id * 3) % 4   -- 0=reg, 1=stack, 2=temp, 3=offset

    -- hex payload: 2-4 digits, derived from id
    local hval   = prng(id * 7 + 1) % 0xFFFF
    local hlen   = 2 + (prng(id * 11) % 3)
    local hex    = toHex(hval, hlen)

    if family == 0 then
        -- _rN_HHHH
        local reg = REGS[regOrder[(id % #REGS) + 1]]
        return "_" .. reg .. "_" .. hex

    elseif family == 1 then
        -- _sp_HHHH or _bp_HHHH etc.
        local sr = STACK[(prng(id * 5) % #STACK) + 1]
        return "_" .. sr .. "_" .. hex

    elseif family == 2 then
        -- _tNN_HHH
        local tmp = TEMPS[tempOrder[(id % #TEMPS) + 1]]
        return "_" .. tmp .. "_" .. hex

    else
        -- _oHHHHH  (offset, shortest)
        return "_o" .. toHex(prng(id * 13) % 0xFFFFF, 4)
    end
end

local function prepare(ast)
    seed = (math.random(0, 0xFFFF) * math.random(1, 0xFFFF)) % 0xFFFFFF

    regOrder  = {}
    tempOrder = {}
    for i = 1, #REGS  do regOrder[i]  = i end
    for i = 1, #TEMPS do tempOrder[i] = i end

    util.shuffle(regOrder)
    util.shuffle(tempOrder)
    util.shuffle(HEX)  -- subtle: reorder hex chars for visual variance run-to-run
end

return {
    generateName = generateName,
    prepare      = prepare,
}
