-- namegenerators/nato.lua
-- NATO — by ZukaTech
--
-- Generates names that look like military/aviation call-signs or
-- telemetry identifiers. Completely reads as legitimate instrument
-- or comms code — nobody suspects obfuscation.
--
-- Visually:  ALPHA_7, BRAVO_3C, FOXTROT_A2, NOVEMBER_9
--
-- Why it works:
--   - Looks intentional and domain-specific, not random
--   - Pattern (WORD_ALPHANUM) is how real avionics/comms code names vars
--   - Passes casual code review as "some constants table"
--   - Wide enough name space to avoid collisions for any realistic script

local util = require("ZukaTech.util")

local NATO_WORDS = {
    "ALPHA", "BRAVO", "CHARLIE", "DELTA", "ECHO",
    "FOXTROT", "GOLF", "HOTEL", "INDIA", "JULIET",
    "KILO", "LIMA", "MIKE", "NOVEMBER", "OSCAR",
    "PAPA", "QUEBEC", "ROMEO", "SIERRA", "TANGO",
    "UNIFORM", "VICTOR", "WHISKEY", "XRAY", "YANKEE", "ZULU",
}

-- Suffix chars: uppercase hex + digits (looks like a serial code)
local SUFFIX_CHARS = {
    "0","1","2","3","4","5","6","7","8","9",
    "A","B","C","D","E","F",
}

-- Separator pool — shuffle each run for variance
local SEPS = { "_", "__" }

local MIN_SUFFIX = 1
local MAX_SUFFIX = 3

local seed    = 0
local order   = {}

local function prng(n)
    n = (n * 2654435761 + seed) % 0x100000000
    local r, b, x, y = 0, 1, n, math.floor(n / 65536)
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then r = r + b end
        x = math.floor(x / 2); y = math.floor(y / 2); b = b * 2
    end
    return r
end

local function generateName(id, scope)
    -- Pick NATO word deterministically from shuffled order
    local wi   = order[(id % #order) + 1]
    local word = NATO_WORDS[wi]

    -- Separator
    local sep = SEPS[(prng(id * 3) % #SEPS) + 1]

    -- Suffix: 1-3 chars from SUFFIX_CHARS
    local slen   = MIN_SUFFIX + (prng(id * 7) % (MAX_SUFFIX - MIN_SUFFIX + 1))
    local suffix = ""
    for i = 0, slen - 1 do
        local idx = (prng(id * 11 + i * 17) % #SUFFIX_CHARS) + 1
        suffix = suffix .. SUFFIX_CHARS[idx]
    end

    -- Tack on a numeric tier derived from how many times this word has cycled
    -- so names stay unique even past 26 variables
    local tier = math.floor(id / #NATO_WORDS)
    if tier > 0 then
        suffix = suffix .. tostring(tier)
    end

    return word .. sep .. suffix
end

local function prepare(ast)
    seed  = math.random(0, 0xFFFFFF)
    order = {}
    for i = 1, #NATO_WORDS do order[i] = i end
    util.shuffle(order)
    util.shuffle(SEPS)
    util.shuffle(SUFFIX_CHARS)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
