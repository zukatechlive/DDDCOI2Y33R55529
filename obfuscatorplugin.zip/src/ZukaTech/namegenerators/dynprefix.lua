-- namegenerators/dynprefix.lua
-- DynPrefix — ZukaTech name generator
--
-- Each compile run picks a completely different prefix style and
-- suffix charset from randomised pools, so two runs of the same
-- script produce names that look like they came from different tools.
--
-- Example outputs per run:
--   Run 1:  _xQ7,  _xQa,  _xQp1,  _xQ3b  ...
--   Run 2:  v_A0,  v_Bc,  v_A19,  v_Dc   ...
--   Run 3:  __mZ,  __nA,  __mZ3,  __oQ   ...
--
-- Prefix pool (one picked randomly per prepare()):
--   single-char:  a–z, A–Z
--   double-char:  two random letters
--   underscore:   _ + random letter,  __ + random letter
--   common-style: v_, l_, m_, n_, s_, x_, y_, z_
--
-- Suffix charset (one picked randomly per prepare()):
--   hex lower,  hex upper,  alphanumeric,  letters only,  digits only
--
-- Uniqueness is guaranteed by appending the raw id when the
-- generated short name would collide (extremely rare, but handled).

local util = require("ZukaTech.util")

-- ─────────────────────────────────────────────────────────────────────────────
-- Module state  (reset every prepare())
-- ─────────────────────────────────────────────────────────────────────────────

local prefix    = "v"    -- chosen at prepare()
local charPool  = {}     -- chosen at prepare(), shuffled each run
local used      = {}     -- collision guard

-- ─────────────────────────────────────────────────────────────────────────────
-- Charset definitions
-- ─────────────────────────────────────────────────────────────────────────────

local CHARSETS = {
    -- hex lower
    {"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"},
    -- hex upper
    {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"},
    -- alphanumeric (no O/0/I/l confusion pairs)
    {"a","b","c","d","e","f","g","h","j","k","m","n","p","q","r","s",
     "t","u","w","x","y","z","2","3","4","5","6","7","8","9"},
    -- lowercase letters only
    {"a","b","c","d","e","f","g","h","i","j","k","l","m",
     "n","o","p","q","r","s","t","u","v","w","x","y","z"},
    -- uppercase letters only
    {"A","B","C","D","E","F","G","H","I","J","K","L","M",
     "N","O","P","Q","R","S","T","U","V","W","X","Y","Z"},
    -- mixed case dense
    {"a","A","b","B","c","C","d","D","e","E","f","F","g","G",
     "h","H","j","J","k","K","m","M","n","N","p","P","q","Q",
     "r","R","s","S","t","T","u","U","w","W","x","X","y","Y"},
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Prefix pool builder
-- ─────────────────────────────────────────────────────────────────────────────

local LETTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

local function randomLetter()
    local i = math.random(1, #LETTERS)
    return LETTERS:sub(i, i)
end

local function buildPrefixPool()
    local pool = {}

    -- single letters (a-z, A-Z)
    for i = 1, #LETTERS do
        pool[#pool + 1] = LETTERS:sub(i, i)
    end

    -- double random letters  (e.g. "qX", "mB")
    for _ = 1, 20 do
        pool[#pool + 1] = randomLetter() .. randomLetter()
    end

    -- underscore styles  (_x, __y)
    for _ = 1, 15 do
        pool[#pool + 1] = "_"  .. randomLetter()
        pool[#pool + 1] = "__" .. randomLetter()
    end

    -- common obfuscator-style prefixes
    local common = {"v_","l_","m_","n_","s_","x_","y_","z_",
                     "V_","L_","M_","N_","S_","X_","Y_","Z_"}
    for _, p in ipairs(common) do
        pool[#pool + 1] = p
    end

    util.shuffle(pool)
    return pool
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Name generation
-- ─────────────────────────────────────────────────────────────────────────────

-- Encode `id` into a base-N string using charPool.
-- Minimum length of 2 suffix chars to avoid single-char name clashes.
local function encodeId(id)
    local base = #charPool
    local s    = ""
    local n    = id
    repeat
        local d = n % base
        n       = math.floor(n / base)
        s       = charPool[d + 1] .. s
    until n == 0 and #s >= 2
    return s
end

local function generateName(id, _scope, _originalName)
    local name = prefix .. encodeId(id)

    -- collision guard (extremely rare but possible with small charsets)
    if used[name] then
        name = name .. "_" .. id
    end
    used[name] = true
    return name
end

-- ─────────────────────────────────────────────────────────────────────────────
-- prepare() — called once per obfuscation run before any names are generated
-- ─────────────────────────────────────────────────────────────────────────────

local function prepare(_ast)
    used = {}

    -- pick a random prefix from the pool
    local prefixPool = buildPrefixPool()
    prefix = prefixPool[math.random(1, #prefixPool)]

    -- pick and shuffle a random charset
    local csIdx = math.random(1, #CHARSETS)
    charPool    = {}
    for i, c in ipairs(CHARSETS[csIdx]) do
        charPool[i] = c
    end
    util.shuffle(charPool)
end

-- ─────────────────────────────────────────────────────────────────────────────

return {
    generateName = generateName,
    prepare      = prepare,
}
