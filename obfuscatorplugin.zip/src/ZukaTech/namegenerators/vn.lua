-- ZukaTech Obfuscator — namegenerators/vn.lua
--
-- VN Name Generator
--
-- Produces names from a shuffled pool of v1–v100 (with optional numeric
-- suffix tier overflow).  Every compilation gets a freshly shuffled pool,
-- so the assignment of original-name → vN label is different each run.
--
-- Strategy:
--   • On prepare(), build the pool {"v1".."v100"} and Fisher-Yates shuffle it.
--   • generateName(id) pops the next name from the pool.
--   • If the pool is exhausted (>100 unique names in one script) a second
--     tier is generated on-the-fly:  v<random 3-digit suffix>_<id>  to
--     guarantee uniqueness while keeping the vN aesthetic.
--
-- The pool is re-shuffled each call to prepare(), so two obfuscation runs
-- of the same source produce completely different vN assignments.

local util = require("ZukaTech.util")

-- ──────────────────────────────────────────────────────────────
-- State (module-level, reset on every prepare())
-- ──────────────────────────────────────────────────────────────

local pool      = {}   -- shuffled list of available names
local poolIdx   = 1    -- next index to hand out
local usedNames = {}   -- collision guard for overflow tier

-- ──────────────────────────────────────────────────────────────
-- Fisher-Yates in-place shuffle (pure Lua 5.1)
-- ──────────────────────────────────────────────────────────────

local function shuffle(t)
    local n = #t
    for i = n, 2, -1 do
        local j = math.random(1, i)
        t[i], t[j] = t[j], t[i]
    end
end

-- ──────────────────────────────────────────────────────────────
-- Overflow name when pool is exhausted
-- ──────────────────────────────────────────────────────────────

local function overflowName(id)
    -- vN_<id> style; retry until not colliding (extremely unlikely)
    local name
    local suffix = math.random(101, 999)
    repeat
        name = "v" .. suffix .. "_" .. id
        suffix = suffix + 1
    until not usedNames[name]
    usedNames[name] = true
    return name
end

-- ──────────────────────────────────────────────────────────────
-- Public interface
-- ──────────────────────────────────────────────────────────────

local function generateName(id, scope, originalName)
    if poolIdx <= #pool then
        local name = pool[poolIdx]
        poolIdx = poolIdx + 1
        usedNames[name] = true
        return name
    else
        -- Pool exhausted — fall through to overflow tier
        return overflowName(id)
    end
end

local function prepare(ast)
    -- Reset state
    pool      = {}
    poolIdx   = 1
    usedNames = {}

    -- Build v1–v100 pool
    for i = 1, 100 do
        pool[i] = "v" .. i
    end

    -- Randomise the order so each compilation maps names differently
    shuffle(pool)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
