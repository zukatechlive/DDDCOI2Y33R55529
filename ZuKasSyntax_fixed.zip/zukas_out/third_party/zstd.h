#pragma once
// Inline ZSTD using Windows Cabinet compression API (MSZIP)
// This satisfies rsb1_encoder.h's ZSTD_compress/compressBound/isError/getErrorName/maxCLevel
#include <windows.h>
#include <compressapi.h>
#include <cstdint>
#include <cstring>
#pragma comment(lib, "Cabinet.lib")

static inline int ZSTD_maxCLevel(void) { return 22; }
static inline size_t ZSTD_compressBound(size_t s) { return s + (s >> 3) + 512; }
static inline unsigned ZSTD_isError(size_t c) { return c == (size_t)(-1); }
static inline const char* ZSTD_getErrorName(size_t c) { (void)c; return "compression_error"; }

static inline size_t ZSTD_compress(void* dst, size_t dstCap, const void* src, size_t srcSize, int level) {
    (void)level;
    COMPRESSOR_HANDLE h = NULL;
    if (!CreateCompressor(COMPRESS_ALGORITHM_LZMS | COMPRESS_RAW, NULL, &h)) {
        if (srcSize <= dstCap) { memcpy(dst, src, srcSize); return srcSize; }
        return (size_t)(-1);
    }
    SIZE_T out = 0;
    BOOL ok = Compress(h, src, (SIZE_T)srcSize, dst, (SIZE_T)dstCap, &out);
    CloseCompressor(h);
    if (!ok || out == 0) {
        if (srcSize <= dstCap) { memcpy(dst, src, srcSize); return srcSize; }
        return (size_t)(-1);
    }
    return (size_t)out;
}
