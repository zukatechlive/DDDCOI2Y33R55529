// Force portable-only BLAKE3 (no SIMD dependencies)
#define BLAKE3_NO_SSE2
#define BLAKE3_NO_SSE41
#define BLAKE3_NO_AVX2
#define BLAKE3_NO_AVX512
#include "blake3.c"
#include "blake3_dispatch.c"
#include "blake3_portable.c"
