@echo off
echo [*] Downloading required third-party headers...

if not exist third_party mkdir third_party
if not exist third_party\nlohmann mkdir third_party\nlohmann

echo [*] Downloading httplib.h...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://github.com/yhirose/cpp-httplib/releases/download/v0.18.5/httplib.h' -OutFile 'third_party\httplib.h'"
if not exist third_party\httplib.h ( echo [ERROR] httplib.h download failed & pause & exit /b 1 )
echo [+] httplib.h OK

echo [*] Downloading nlohmann/json.hpp...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp' -OutFile 'third_party\nlohmann\json.hpp'"
if not exist third_party\nlohmann\json.hpp ( echo [ERROR] json.hpp download failed & pause & exit /b 1 )
echo [+] nlohmann/json.hpp OK

echo [*] Downloading blake3 sources...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/BLAKE3-team/BLAKE3/master/c/blake3.h' -OutFile 'third_party\blake3.h'"
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/BLAKE3-team/BLAKE3/master/c/blake3_impl.h' -OutFile 'third_party\blake3_impl.h'"
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/BLAKE3-team/BLAKE3/master/c/blake3.c' -OutFile 'third_party\blake3.c'"
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/BLAKE3-team/BLAKE3/master/c/blake3_dispatch.c' -OutFile 'third_party\blake3_dispatch.c'"
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/BLAKE3-team/BLAKE3/master/c/blake3_portable.c' -OutFile 'third_party\blake3_portable.c'"
echo [+] blake3 OK
echo [*] Creating blake3_all.c...
(echo #define BLAKE3_NO_SSE2 & echo #define BLAKE3_NO_SSE41 & echo #define BLAKE3_NO_AVX2 & echo #define BLAKE3_NO_AVX512 & echo #include "blake3.c" & echo #include "blake3_dispatch.c" & echo #include "blake3_portable.c") > third_party\blake3_all.c

echo [*] Downloading xxhash.h...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/Cyan4973/xxHash/dev/xxhash.h' -OutFile 'third_party\xxhash.h'"
if not exist third_party\xxhash.h ( echo [ERROR] xxhash.h download failed & pause & exit /b 1 )
echo [+] xxhash.h OK

echo [*] Downloading zstd single-header...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/facebook/zstd/dev/lib/zstd.h' -OutFile 'third_party\zstd.h'"
echo [+] zstd.h OK

echo.
echo [+] All dependencies downloaded. Run build.bat to compile.
pause
