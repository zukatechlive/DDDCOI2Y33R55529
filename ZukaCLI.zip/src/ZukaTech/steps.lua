return {
	InvertedExecution    = require("ZukaTech.steps.InvertedExecution");
	WrapInFunction       = require("ZukaTech.steps.WrapInFunction");
	SplitStrings         = require("ZukaTech.steps.SplitStrings");
	Vmify                = require("ZukaTech.steps.Vmify");
	ConstantArray        = require("ZukaTech.steps.ConstantArray");
	ProxifyLocals        = require("ZukaTech.steps.ProxifyLocals");
	AntiTamper           = require("ZukaTech.steps.AntiTamper");
	EncryptStrings       = require("ZukaTech.steps.EncryptStrings");
	NumbersToExpressions = require("ZukaTech.steps.NumbersToExpressions");
	AddVararg            = require("ZukaTech.steps.AddVararg");
	WatermarkCheck       = require("ZukaTech.steps.WatermarkCheck");
	JunkStatements       = require("ZukaTech.steps.JunkStatements");
	FakeLoopWrap         = require("ZukaTech.steps.FakeLoopWrap");
	-- Tier 1 upgrades
	DynamicXOR           = require("ZukaTech.steps.DynamicXOR");
	-- Tier 2 upgrades: advanced dynamic constant decryption and instruction jumps
	DynamicDecrypt       = require("ZukaTech.steps.DynamicDecrypt");
	DynamicJumps         = require("ZukaTech.steps.DynamicJumps");
	OpaquePredicates     = require("ZukaTech.steps.OpaquePredicates");
	AntiDump             = require("ZukaTech.steps.AntiDump");
	IntegrityHash        = require("ZukaTech.steps.IntegrityHash");
	VirtualGlobals       = require("ZukaTech.steps.VirtualGlobals");
	-- New steps from NewThingsToAdd
	Compressor           = require("ZukaTech.steps.Compressor");
	HookDetection        = require("ZukaTech.steps.HookDetection");
	ConstantsObfuscator  = require("ZukaTech.steps.ConstantsObfuscator");
	StatementFlattener   = require("ZukaTech.steps.StatementFlattener");
	-- Luraph-pattern upgrades
	CffIntegrity         = require("ZukaTech.steps.CffIntegrity");
	XorTable             = require("ZukaTech.steps.XorTable");
	ShadowRegisters      = require("ZukaTech.steps.ShadowRegisters");
	PcallSilencer        = require("ZukaTech.steps.PcallSilencer");
	-- IronBrew2-pattern upgrades
	BlobCompress         = require("ZukaTech.steps.BlobCompress");
	-- Custom bytecode backend
	VmifyBC              = require("ZukaTech.steps.VmifyBC");
	-- Post-unparse visual obfuscation (runs after BlobCompress)
	ZukaZalgo            = require("ZukaTech.steps.ZukaZalgo");
	Cuteify              = require("ZukaTech.steps.Cuteify");
	-- Post-unparse source-level passes
	VariableRenamer      = require("ZukaTech.steps.VariableRenamer");
	BytecodeEncoder      = require("ZukaTech.steps.BytecodeEncoder");
        CrewmateFormat       = require("ZukaTech.steps.Crewmateformat");
	ExecutorGuard        = require("ZukaTech.steps.ExecutorGuard");
}
