-- This Script is Part of the ZukaTech Obfuscator by Levno_710
--
-- Vmify.lua
--
-- This Script provides a Complex Obfuscation Step that will compile the entire Script to a fully custom bytecode that does not share it's instructions
-- with lua, making it much harder to crack than other lua obfuscators
--
-- OptimizationLevel setting replicates Luraph's optimization levels:
--   0  - No optimization (default, safest, identical to old behaviour)
--   1  - Constant Folding + Jump Merging
--   2  - Level 1 + Constant Propagation  (Luraph's default level)
--   3  - Level 2 + Global Import Localization + Global Constant Folding

local Step      = require("ZukaTech.step");
local Compiler  = require("ZukaTech.compiler.compiler");
local Optimizer = require("ZukaTech.optimizer");

local Vmify = Step:extend();
Vmify.Description = "Compiles your script into a fully-custom bytecode VM format. " ..
                    "OptimizationLevel mirrors Luraph's optimizer: " ..
                    "0=none, 1=fold+jump-merge, 2=+propagation, 3=+global-localization.";
Vmify.Name = "Vmify";

Vmify.SettingsDescriptor = {
    OptimizationLevel = {
        type    = "number";
        default = 0;    -- safe default: identical to original behaviour
        min     = 0;
        max     = 3;
    };
}

function Vmify:init(settings)
    settings = settings or {};
    self.optimizationLevel = settings.OptimizationLevel or 0;
end

function Vmify:apply(ast)
    local level = self.optimizationLevel;

    -- ── Pre-compile optimization pass ────────────────────────────
    if level >= 1 then
        local optimizer = Optimizer:new(level);

        -- Attempt to retrieve the global scope for Level 3 global localization
        local globalScope = nil;
        if ast.globalScope then
            globalScope = ast.globalScope;
        elseif ast.body and ast.body.scope then
            local s = ast.body.scope;
            while s and s.parentScope do s = s.parentScope end
            globalScope = s;
        end

        -- Run pre-compile passes (fold, propagate, global opts)
        ast = optimizer:optimize(ast, globalScope);

        -- Compile, injecting a post-compile hook for jump merging
        local compiler = Compiler:new();
        local originalCompileTopNode = compiler.compileTopNode;
        compiler.compileTopNode = function(self_c, node)
            originalCompileTopNode(self_c, node);
            -- Level 1+: merge trivial single-jump blocks after block graph is built
            optimizer:postCompilePass(self_c);
        end;

        return compiler:compile(ast);
    end

    -- ── No optimization — original behaviour ─────────────────────
    local compiler = Compiler:new();
    return compiler:compile(ast);
end

return Vmify;