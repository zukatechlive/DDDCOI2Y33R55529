-- steps/BytecodeEncoder.lua
-- ZukaTech Obfuscation Step: Bytecode Encoder
--
-- Runs AFTER the AST is unparsed to source (post-unparse pass).
-- Compiles the source to Lua bytecode via string.dump(load(src)),
-- applies a random-offset Caesar cipher to every byte, then wraps
-- the hex-encoded blob in a self-contained runtime decoder stub.
--
-- Compatible with standard Lua 5.1 executors (uses load / loadstring).
-- NOTE: This step requires the executor environment to support
--       string.dump and load/loadstring with bytecode input.
--
-- Add to your preset Steps table (place AFTER other source-level steps,
-- BEFORE ZukaZalgo / BlobCompress if you want those to wrap the stub):
--   { Name = "BytecodeEncoder", Settings = {} }
--
-- Settings: none currently (offset is randomised per compile).

local Step   = require("ZukaTech.step")
local logger = require("logger")

-- ── core logic (ported from bytecode_encoder.lua) ────────────────────────────

local function encodeBytecode(bytecode, offset)
    local encoded = {}
    for i = 1, #bytecode do
        local byte        = bytecode:byte(i)
        local shifted     = (byte + offset) % 256
        encoded[#encoded + 1] = string.format("%02X", shifted)
    end
    return table.concat(encoded)
end

-- Three structurally distinct stub shapes so the fingerprint varies.
local stubs = {
    -- Shape 1: named locals, explicit loop
    [[local _e, _o, _d = "%s", %d, {}
for _i = 1, #_e, 2 do
    local _b = tonumber(_e:sub(_i, _i + 1), 16)
    _b = (_b - _o + 256) %% 256
    _d[#_d + 1] = string.char(_b)
end
assert(load(table.concat(_d)))(  )]],

    -- Shape 2: single-expression, compact
    [[local _h,_k="%s",%d
local _t={}
local _s=string
local _tc=table.concat
for _i=1,#_h,2 do _t[#_t+1]=_s.char((_s.byte(_s.sub(_h,_i,_i+1)~=nil and tonumber(_s.sub(_h,_i,_i+1),16) or 0)-_k+256)%%256) end
;(assert(load(_tc(_t))))(  )]],

    -- Shape 3: while-loop with index variable
    [[local _blob,_off,_buf="%s",%d,{}
local _idx=1
while _idx<=#_blob do
    local _v=tonumber(_blob:sub(_idx,_idx+1),16)
    _buf[#_buf+1]=string.char((_v-_off+256)%%256)
    _idx=_idx+2
end
local _fn=assert(load(table.concat(_buf)))
_fn(  )]],
}

local function buildStub(encoded, offset)
    local shape = stubs[math.random(1, #stubs)]
    return string.format(shape, encoded, offset)
end

local function processSource(code)
    -- We need a standard Lua load / loadstring available at step-build time.
    -- Lua 5.1: loadstring() compiles a string.
    -- Lua 5.2+: load() accepts strings directly.
    local loader = loadstring or (type(load) == "function" and function(s)
        return load(s)
    end)
    if not loader then
        logger:warn("[BytecodeEncoder] load/loadstring not available — skipping.")
        return code
    end

    local fn, err = loader(code)
    if not fn then
        logger:warn("[BytecodeEncoder] Failed to compile source: " .. tostring(err) .. " — skipping.")
        return code
    end

    local ok, bytecode = pcall(string.dump, fn)
    if not ok or not bytecode or #bytecode == 0 then
        logger:warn("[BytecodeEncoder] string.dump failed — skipping.")
        return code
    end

    local offset  = math.random(1, 255)
    local encoded = encodeBytecode(bytecode, offset)
    local stub    = buildStub(encoded, offset)

    logger:info(string.format("[BytecodeEncoder] Encoded %d bytes → %d hex chars (offset %d)",
        #bytecode, #encoded, offset))
    return stub
end

-- ── Step interface ────────────────────────────────────────────────────────────

local BytecodeEncoder = Step:extend()
BytecodeEncoder.Name        = "BytecodeEncoder"
BytecodeEncoder.Description = "Post-unparse pass: compiles source to bytecode, Caesar-shifts every byte, wraps in a hex-decode stub."

BytecodeEncoder.SettingsDescriptor = {}

function BytecodeEncoder:init(settings) end

-- Register as a post-unparse pass.
-- Placed BEFORE BlobCompress / ZukaZalgo in the timing order so those
-- passes can optionally wrap the resulting stub.
function BytecodeEncoder:apply(ast, pipeline)
    if pipeline._bytecodeEncoderStep then
        logger:warn("[BytecodeEncoder] Multiple BytecodeEncoder steps — last one wins.")
    end
    pipeline._bytecodeEncoderStep = self
    return ast  -- real work is in :process()
end

-- Called by the pipeline post-unparse hook (see pipeline.lua patch).
function BytecodeEncoder:process(source)
    logger:info("[BytecodeEncoder] Encoding bytecode …")
    local result = processSource(source)
    logger:info("[BytecodeEncoder] Done.")
    return result
end

return BytecodeEncoder