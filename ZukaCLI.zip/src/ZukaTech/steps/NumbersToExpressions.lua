unpack = unpack or table.unpack;
local Step = require("ZukaTech.step");
local Ast = require("ZukaTech.ast");
local Scope = require("ZukaTech.scope");
local visitast = require("ZukaTech.visitast");
local util     = require("ZukaTech.util")
local AstKind = Ast.AstKind;
local NumbersToExpressions = Step:extend();
NumbersToExpressions.Description = "This Step Converts number Literals to Expressions";
NumbersToExpressions.Name = "Numbers To Expressions";
NumbersToExpressions.SettingsDescriptor = {
	Treshold = {
        type = "number",
        default = 1,
        min = 0,
        max = 1,
    },
    InternalTreshold = {
        type = "number",
        default = 0.2,
        min = 0,
        max = 0.8,
    }
}
function NumbersToExpressions:init(settings)
    self.ExpressionGenerators = {
        function(val, depth)
            local a = math.random(-2^20, 2^20);
            local b = val - a;
            if tonumber(tostring(b)) + tonumber(tostring(a)) ~= val then return false end
            return Ast.AddExpression(
                self:CreateNumberExpression(a, depth),
                self:CreateNumberExpression(b, depth)
            );
        end,
        function(val, depth)
            local a = math.random(-2^20, 2^20);
            local b = val + a;
            if tonumber(tostring(b)) - tonumber(tostring(a)) ~= val then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(b, depth),
                self:CreateNumberExpression(a, depth)
            );
        end,
        function(val, depth)
            if val == 0 then return false end
            local factors = {3, 5, 7, 11, 13};
            local a = factors[math.random(#factors)];
            local b = val / a;
            if math.floor(b) ~= b then return false end
            if tonumber(tostring(b)) * tonumber(tostring(a)) ~= val then return false end
            return Ast.MulExpression(
                self:CreateNumberExpression(b, depth),
                self:CreateNumberExpression(a, depth)
            );
        end,
        function(val, depth)
            if val < 0 or val > 4294967295 or math.floor(val) ~= val then return false end
            local ok, bit = pcall(require, "bit")
            if not ok then ok, bit = pcall(require, "bit32") end
            if not ok then return false end
            local bxor = bit.bxor or bit32 and bit32.bxor
            if not bxor then return false end
            local mask = math.random(1, 65535);
            local xored = bxor(val, mask);
            local band = bit.band or bit32 and bit32.band
            if not band then return false end
            local andval = band(xored, mask);
            local sum = xored + mask;
            local twice_and = 2 * andval;
            if sum - twice_and ~= val then return false end
            if sum > 2^53 or twice_and > 2^53 then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(sum, depth),
                self:CreateNumberExpression(twice_and, depth)
            );
        end,
        function(val, depth)
            if val < 0 or val > 2^20 or math.floor(val) ~= val then return false end
            local modulus = val + math.random(1, 1024);
            local k = math.random(2, 8);
            local big = modulus * k + val;
            if big % modulus ~= val then return false end
            if big > 2^53 then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(big, depth),
                self:CreateNumberExpression(modulus * k, depth)
            );
        end,
        function(val, depth)
            if val < 0 or val > 65535 or math.floor(val) ~= val then return false end
            local hi = math.floor(val / 256)
            local lo = val % 256
            if hi == 0 then return false end
            return Ast.AddExpression(
                self:CreateNumberExpression(hi * 256, depth),
                self:CreateNumberExpression(lo, depth)
            )
        end,
        function(val, depth)
            if val < 0 or val > 4294967295 or math.floor(val) ~= val then return false end
            local mask = math.random(0x1000, 0xFFFF)
            local a = val + mask
            if a - mask ~= val then return false end
            if a > 2^53 then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(a, depth),
                self:CreateNumberExpression(mask, depth)
            )
        end,
    }
end
function NumbersToExpressions:CreateNumberExpression(val, depth)
    if depth > 0 and math.random() >= self.InternalTreshold or depth > 15 then
        return Ast.NumberExpression(val)
    end
    local generators = util.shuffle({unpack(self.ExpressionGenerators)});
    for i, generator in ipairs(generators) do
        local node = generator(val, depth + 1);
        if node then
            return node;
        end
    end
    return Ast.NumberExpression(val)
end
function NumbersToExpressions:apply(ast)
	visitast(ast, nil, function(node, data)
        if node.kind == AstKind.NumberExpression then
            if math.random() <= self.Treshold then
                return self:CreateNumberExpression(node.value, 0);
            end
        end
    end);
end
return NumbersToExpressions;