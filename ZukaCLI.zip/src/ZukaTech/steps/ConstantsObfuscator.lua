-- Obfuscation Step: Constants Obfuscator

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local visitast = require("ZukaTech.visitast")

local AstKind  = Ast.AstKind

local ConstantsObfuscator       = Step:extend()
ConstantsObfuscator.Description = "Replaces number and string literals with setmetatable-based algebraic expressions (x²-y²+z identity)."
ConstantsObfuscator.Name        = "Constants Obfuscator"

ConstantsObfuscator.SettingsDescriptor = {
    ObfuscateNumbers = {
        type    = "boolean",
        default = true,
    },
    ObfuscateStrings = {
        type    = "boolean",
        default = true,
    },
    MockStringChance = {
        type    = "number",
        default = 10,
        min     = 1,
        max     = 100,
    },
    MinAbsValue = {
        type    = "number",
        default = 2,
        min     = 0,
        max     = 1e9,
    },
}

-- FIX: replaced readable English phrases with short random-looking tokens.
-- Human-readable strings are ironically easier to fingerprint in deobfuscators
-- that scan for ASCII clusters. Short alphanumeric noise blends in better.
local MOCKING_STRINGS = {
    "k7qL2mX",
    "nT5vR8pW",
    "gB3dH6jY",
    "cF9wA1sZ",
    "xU4eI0oQ",
}

-- FIX: removed __concat (".." operator) from the table.
-- setmetatable({}, ...) .. {x,y,z} is not valid Lua — tables cannot be
-- concatenated with .. even with __concat defined on only the left side.
-- The right-hand operand {x,y,z} is a plain table with no metamethod, so Lua
-- raises "attempt to concatenate a table value" before the metamethod fires.
local OPERATORS = {
    { sym = "^",  mm = "__pow"    },
    { sym = "*",  mm = "__mul"    },
    { sym = "/",  mm = "__div"    },
    { sym = "+",  mm = "__add"    },
    { sym = "-",  mm = "__sub"    },
    { sym = "%",  mm = "__mod"    },
}

-- ── Helper: solve x*x - y*y + z = target ───────────────────────────────────
-- FIX: extended to handle negative targets. For a negative target, we want
-- y*y > x*x, so we swap the roles: pick y > x and let z adjust.
-- We also cap attempts and return nil cleanly on failure rather than
-- spinning the full 1000 iterations for impossible inputs.
local function solveTriple(target)
    -- For negative targets the identity x²-y²+z=N still works: just
    -- let z be large enough to absorb the difference. However to keep
    -- emitted numbers small and avoid parser headaches we handle sign
    -- by symmetry: solve for |target| then negate z.
    if target ~= math.floor(target) then return nil end  -- non-integer: skip

    local abs_target = math.abs(target)
    local sign = (target < 0) and -1 or 1

    for _ = 1, 500 do
        local x = math.random(1, 2^14)   -- tighter range: smaller literals
        local y = math.random(1, 2^14)
        local z = abs_target - x*x + y*y
        -- z must be representable and the identity must hold exactly
        if x*x - y*y + z == abs_target then
            return x, y, sign * z
        end
    end
    return nil
end

-- ── AST helpers ─────────────────────────────────────────────────────────────
local _parser = nil
local function getParser()
    if not _parser then
        local Parser = require("ZukaTech.parser")
        local Enums  = require("ZukaTech.enums")
        _parser = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 })
    end
    return _parser
end

local function parseExpr(src)
    local p   = getParser()
    local ok, result = pcall(function()
        return p:parse("return " .. src)
    end)
    if not ok then return nil end
    local stmts = result and result.body and result.body.statements
    if stmts and stmts[1] and stmts[1].values then
        return stmts[1].values[1]
    end
    return nil
end

-- ── Number obfuscation ──────────────────────────────────────────────────────
local function obfuscateNumber(value, mockChance, minAbs)
    if math.abs(value) < minAbs then return nil end
    if value ~= math.floor(value) then return nil end

    local x, y, z = solveTriple(value)
    if not x then return nil end

    local mockLen = 0
    local mockStr = nil
    if math.random(1, mockChance) == 1 and math.abs(value) >= 100 then
        mockStr  = MOCKING_STRINGS[math.random(#MOCKING_STRINGS)]
        mockLen  = #mockStr
    end

    local op  = OPERATORS[math.random(#OPERATORS)]

    local snippet
    if mockStr then
        -- z is already signed, so add mockLen to it for the mock offset trick
        snippet = string.format(
            [[setmetatable({},{["%s"]=function(_,a)local x,y,z=a[1],a[2],a[3];return x*x-y*y+z end})%s{%d,%d,%d}+%d-#"%s"]],
            op.mm, op.sym, x, y, z + mockLen, mockLen, mockStr
        )
    else
        snippet = string.format(
            [[setmetatable({},{["%s"]=function(_,a)local x,y,z=a[1],a[2],a[3];return x*x-y*y+z end})%s{%d,%d,%d}]],
            op.mm, op.sym, x, y, z
        )
    end
    return parseExpr(snippet)
end

-- ── String obfuscation ──────────────────────────────────────────────────────
local function obfuscateString(value)
    if #value == 0 then return nil end

    local parts = {}
    for i = 1, #value do
        local b = value:byte(i)
        local x, y, z = solveTriple(b)
        if not x then return nil end
        parts[i] = string.format("{%d,%d,%d}", x, y, z)
    end

    local op = OPERATORS[math.random(#OPERATORS)]
    local snippet = string.format(
        [[setmetatable({},{["%s"]=function(_,a)local s=""local i=1 while a[i] do local t=a[i];s=s..string.char(t[1]*t[1]-t[2]*t[2]+t[3]);i=i+1 end return s end})%s{%s}]],
        op.mm, op.sym, table.concat(parts, ",")
    )
    return parseExpr(snippet)
end

-- ── Step interface ──────────────────────────────────────────────────────────

function ConstantsObfuscator:init(settings) end

function ConstantsObfuscator:apply(ast, pipeline)
    local obfNums  = self.ObfuscateNumbers
    local obfStrs  = self.ObfuscateStrings
    local mockCh   = self.MockStringChance
    local minAbs   = self.MinAbsValue

    -- FIX: use the visitor's return-value API (same as EncryptStrings does)
    -- instead of mutating node fields in-place. In-place mutation is unsafe
    -- because the walker may hold references to the original field values
    -- before the node is visited, leading to stale reads after the wipe.
    visitast(ast, nil, function(node, data)
        if obfNums and node.kind == AstKind.NumberExpression then
            local replacement = obfuscateNumber(node.value, mockCh, minAbs)
            if replacement then
                return replacement
            end

        elseif obfStrs and node.kind == AstKind.StringExpression then
            if #node.value >= 2 then
                local replacement = obfuscateString(node.value)
                if replacement then
                    return replacement
                end
            end
        end
    end)

    return ast
end

return ConstantsObfuscator