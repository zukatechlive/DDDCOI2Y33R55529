-- Obfuscation Step: Hook Detection
--
-- Ports detectFuckyHooks.lua (from NewThingsToAdd) into the Zuraph pipeline.
--
-- What it does:
--   Prepends a self-referential trampoline function at the top of the AST
--   that will spin into an infinite crash-loop if the executor has hooked
--   any global function (e.g. debug.getinfo, getmetatable, getfenv) away
--   from their native [C] implementations.
--
-- How it works:
--   1. debug.getinfo is used to verify that every checked function still
--      reports short_src == "[C]" (i.e. not replaced by a Lua wrapper).
--   2. The global environment table is inspected: every function value must
--      still point to a [C] function.
--   3. The function's own upvalues are checked against _G to detect upvalue
--      injection (a common executor technique).
--   4. Any deviation calls dtct_func recursively with mixed arguments,
--      causing a stack overflow — a reliable silent crash.
--
-- The injected guard uses only Lua 5.1 / LuaU compatible primitives:
--   getfenv (polyfilled to return _G when absent, i.e. Luau), getmetatable,
--   debug.getinfo, debug.getupvalue.

local Step   = require("ZukaTech.step")
local Ast    = require("ZukaTech.ast")
local Parser = require("ZukaTech.parser")
local Enums  = require("ZukaTech.enums")

local LuaVersion = Enums.LuaVersion

local HookDetection       = Step:extend()
HookDetection.Description = "Injects a recursive hook-detection trampoline that crashes the script if executor hooks on debug/getfenv/getmetatable are detected."
HookDetection.Name        = "Hook Detection"

HookDetection.SettingsDescriptor = {
    CheckGlobals = {
        type    = "boolean",
        default = true,
    },
    CheckUpvalues = {
        type    = "boolean",
        default = true,
    },
}

function HookDetection:init(settings) end

function HookDetection:apply(ast, pipeline)
    local checkGlobals  = self.CheckGlobals
    local checkUpvalues = self.CheckUpvalues

    -- Build the guard code.  The function name is randomised each run so
    -- static-string searches by deobfuscators won't find a stable target.
    local fnName = "_hd" .. math.random(10000, 99999)
    local sentinelKey = "_zs" .. math.random(10000, 99999)

    -- Conditionally include the globals and upvalue checks
    local globalsCheck = ""
    if checkGlobals then
        globalsCheck = string.format([[
    -- Check every global function is still a native [C] function
    for _k, _v in pairs(_G_ref) do
      while type(_v) == "function" and _dbg_info(_v)["short_src"] ~= "[C]" do
        return %s({...}, ...)
      end
    end
]], fnName)
    end

    local upvalueCheck = ""
    if checkUpvalues then
        upvalueCheck = string.format([[
    -- Upvalue injection check
    local _nups = _info["nups"]
    for _i = 1, _nups do
      local _un, _uv = _dbg_upv(_dbg_info, _i)
      while _uv ~= _G_ref[_un] do
        return %s({...}, ...)
      end
    end
]], fnName)
    end

    local code = string.format([[
do
  local %s
  %s = function(...)
    local _args = {...}
    -- If called with a table as first arg it's a recursive crash call
    if type(_args[1]) == "table" then
      return %s(...)
    end

    local _dbg   = debug
    local _G_ref = _G
    local _gmt   = getmetatable
    local _gfe   = (getfenv or function() return _G_ref end)

    -- Verify debug library is still native
    local _dbg_info = _dbg["getinfo"]
    local _dbg_upv  = _dbg["getupvalue"]

    -- Check our own call frame is still a [C] origin concern
    local _info = _dbg_info(%s)
    while _info["short_src"] ~= "[C]" or _gmt(_info) do
      return %s({...}, ...)
    end

    -- Check getinfo's environment hasn't been tampered with
    while _gfe(_dbg_info) ~= _G_ref or _gmt(_G_ref) do
      return %s({...}, ...)
    end

%s
%s

    -- All checks passed — return the guard itself as a safe sentinel
    return %s
  end

  -- Run the check immediately on load.
  -- NOTE: _G is intentionally NOT mutated here — setmetatable(_G,_G) is a
  -- known fingerprint that crashes on executors with locked metatables and
  -- is trivially grep-able. Instead we snapshot the specific globals we care
  -- about into a local proxy and validate only those on each check call.
  -- This achieves the same tamper-detection goal without the fingerprint.
  local _%s = {
    _pc = pcall, _er = error, _dbg = debug,
    _ts = tostring, _gmt = getmetatable,
  }
  -- Validate snapshot vs live _G now to catch any hooks already in place.
  for _k, _v in pairs(_%s) do
    if _G_ref and _G_ref[_k] ~= nil and type(_v) == "function" then
      if _dbg_info(_v) and _dbg_info(_v)["short_src"] ~= "[C]" then
        %s({}, 0)
      end
    end
  end

  -- Run the full check immediately on load
  %s(0)
end
]],
        fnName, fnName,     -- local decl
        fnName,             -- crash recurse inside type check
        fnName,             -- _dbg_info(fnName)
        fnName,             -- crash: short_src check
        fnName,             -- crash: env check
        globalsCheck,
        upvalueCheck,
        fnName,             -- return sentinel
        sentinelKey, sentinelKey,  -- proxy table name x2
        fnName,             -- crash call in snapshot validation
        fnName              -- initial full check call
    )

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(code) end)
    if not ok then
        -- Parsing failed (e.g. Luau-only host): skip injection silently
        return ast
    end

    -- Prepend the do-block to the AST
    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    return ast
end

return HookDetection
