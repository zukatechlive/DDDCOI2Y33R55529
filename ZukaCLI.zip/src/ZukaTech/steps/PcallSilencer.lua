-- This Script is Part of the ZukaTech Obfuscator
--
-- PcallSilencer.lua
--
-- Implements the pcall-override pattern observed in Luraph:
--   • The real pcall is saved to a local before the hook.
--   • The global pcall is replaced with a no-op (or a forwarding shim).
--   • This breaks executor-side scripts that wrap the obfuscated output in
--     pcall(...) to catch errors and inspect the environment at throw time.
--   • Two modes:
--       "noop"    – pcall is replaced with a function that always returns
--                   false, nil.  Very aggressive; may break scripts that
--                   legitimately use pcall internally.
--       "forward" – pcall is replaced with a shim that only blocks outer
--                   callers (depth > threshold).  The script's own pcall
--                   calls are routed through the saved real pcall.
--   • The saved real pcall is still injected into the AST as a scoped local
--     so other steps (AntiTamper, etc.) that rely on pcall continue to work.
--
-- Lua 5.1 / Luau compatible.

local Step          = require("ZukaTech.step")
local Ast           = require("ZukaTech.ast")
local Scope         = require("ZukaTech.scope")
local Parser        = require("ZukaTech.parser")
local Enums         = require("ZukaTech.enums")
local RandomStrings = require("ZukaTech.randomStrings")

local LuaVersion = Enums.LuaVersion

local PcallSilencer       = Step:extend()
PcallSilencer.Description = "Overrides the global pcall with a no-op or depth-limited shim (Luraph pcall hook pattern). Prevents executors from wrapping the script in pcall to catch/inspect errors."
PcallSilencer.Name        = "Pcall Silencer"

PcallSilencer.SettingsDescriptor = {
    Mode = {
        name        = "Mode",
        description = "noop = always return false; forward = shim that blocks outer pcall but allows internal ones",
        type        = "string",
        default     = "forward",
    },
    MaxDepth = {
        name        = "MaxDepth",
        description = "(forward mode only) stack depth threshold beyond which the shim becomes a passthrough. Lower = more aggressive blocking.",
        type        = "number",
        default     = 4,
        min         = 1,
        max         = 20,
    },
}

function PcallSilencer:init(settings) end

function PcallSilencer:apply(ast, pipeline)
    local mode     = (self.Mode or "forward")
    local maxDepth = math.max(1, math.floor(self.MaxDepth or 4))

    -- Random identifiers to avoid fingerprinting
    local realPcallName = "_rpc_" .. RandomStrings.randomString(6)
    local shimName      = "_spc_" .. RandomStrings.randomString(6)

    local code
    if mode == "noop" then
        -- Aggressively replace pcall with a function that does nothing.
        -- The real pcall is saved so internal uses by ZukaTech-injected code
        -- can still use it via the local name.
        code = string.format([[
do
    local %s = pcall
    pcall = function()
        -- Silenced
    end
end
]], realPcallName)
    else
        -- "forward" mode: shim that checks debug.traceback depth.
        -- If the call originates from a shallow stack (executor wrapping),
        -- silenced.  If from a deeper stack (internal script logic), forwarded.
        -- Falls back gracefully when debug is unavailable.
        code = string.format([[
do
    local %s = pcall
    local _depth_limit = %d
    local _debug = debug
    pcall = function(f, ...)
        -- Check if call is from a shallow stack (external wrapping)
        if _debug and _debug.traceback then
            local tb  = _debug.traceback("", 2)
            local cnt = 0
            for _ in tb:gmatch("\n") do
                cnt = cnt + 1
            end
            if cnt <= _depth_limit then
                -- External caller — silenced
                return false
            end
        end
        return %s(f, ...)
    end
end
]], realPcallName, maxDepth, realPcallName)
    end

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local parsed = parser:parse(code)

    local doStat    = parsed.body.statements[1]
    local rootScope = ast.body.scope
    doStat.body.scope:setParent(rootScope)

    -- Prepend so it fires before anything else
    table.insert(ast.body.statements, 1, doStat)

    return ast
end

return PcallSilencer
