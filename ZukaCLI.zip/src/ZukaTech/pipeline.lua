-- pipeline.lua
-- Configurable obfuscation pipeline

local config = require("config");
local Ast    = require("ZukaTech.ast");
local Enums  = require("ZukaTech.enums");
local util = require("ZukaTech.util");
local Parser = require("ZukaTech.parser");
local Unparser = require("ZukaTech.unparser");
local logger = require("logger");

local NameGenerators = require("ZukaTech.namegenerators");

local Steps = require("ZukaTech.steps");

local lookupify = util.lookupify;
local LuaVersion = Enums.LuaVersion;
local AstKind = Ast.AstKind;

-- Use clock on Windows, time elsewhere
local _winplatform = package and package.config and type(package.config) == "string" and package.config:sub(1,1) == "\\";
local function gettime()
	if _winplatform then
		return os.clock();
	else
		return os.time();
	end
end

local Pipeline = {
	NameGenerators = NameGenerators;
	Steps = Steps;
	DefaultSettings = {
		LuaVersion = LuaVersion.LuaU; -- The Lua Version to use for the Tokenizer, Parser and Unparser
		PrettyPrint = false; -- Note that Pretty Print is currently not producing Pretty results
		Seed = 0; -- The Seed. 0 or below uses the current time as a seed
		VarNamePrefix = ""; -- The Prefix that every variable will start with
	}
}


function Pipeline:new(settings)
	local luaVersion = settings.luaVersion or settings.LuaVersion or Pipeline.DefaultSettings.LuaVersion;
	local conventions = Enums.Conventions[luaVersion];
	if(not conventions) then
		logger:error("The Lua Version \"" .. luaVersion 
			.. "\" is not recognised by the Tokenizer! Please use one of the following: \"" .. table.concat(util.keys(Enums.Conventions), "\",\"") .. "\"");
	end
	
	local prettyPrint = settings.PrettyPrint or Pipeline.DefaultSettings.PrettyPrint;
	local prefix = settings.VarNamePrefix or Pipeline.DefaultSettings.VarNamePrefix;
	local seed = settings.Seed or 0;
	
	local pipeline = {
		LuaVersion = luaVersion;
		PrettyPrint = prettyPrint;
		VarNamePrefix = prefix;
		Seed = seed;
		parser = Parser:new({
			LuaVersion = luaVersion;
		});
		unparser = Unparser:new({
			LuaVersion = luaVersion;
			PrettyPrint = prettyPrint;
			Highlight = settings.Highlight;
		});
		namegenerator = nil; -- set by setNameGenerator; nil means use preset/config value
		conventions = conventions;
		steps = {};
	}
	
	setmetatable(pipeline, self);
	self.__index = self;
	
	return pipeline;
end

function Pipeline:fromConfig(config)
	config = config or {};
	local pipeline = Pipeline:new({
		LuaVersion    = config.LuaVersion or LuaVersion.Lua51;
		PrettyPrint   = config.PrettyPrint or false;
		VarNamePrefix = config.VarNamePrefix or "";
		Seed          = config.Seed or 0;
	});

	pipeline:setNameGenerator(config.NameGenerator or "Mangled")

	-- Add all Steps defined in Config
	local steps = config.Steps or {};
	for i, step in ipairs(steps) do
		if type(step.Name) ~= "string" then
			logger:error("Step.Name must be a String");
		end
		local constructor = pipeline.Steps[step.Name];
		if not constructor then
			logger:error(string.format("The Step \"%s\" was not found!", step.Name));
		end
		pipeline:addStep(constructor:new(step.Settings or {}));
	end

	return pipeline;
end

function Pipeline:addStep(step)
	table.insert(self.steps, step);
end

function Pipeline:resetSteps(step)
	self.steps = {};
end

function Pipeline:getSteps()
	return self.steps;
end

function Pipeline:setOption(name, value)
	if Pipeline.DefaultSettings[name] ~= nil then
		self[name] = value;
	else
		logger:error(string.format("\"%s\" is not a valid pipeline option", tostring(name)));
	end
end

function Pipeline:setLuaVersion(luaVersion)
	local conventions = Enums.Conventions[luaVersion];
	if(not conventions) then
		logger:error("The Lua Version \"" .. luaVersion 
			.. "\" is not recognised by the Tokenizer! Please use one of the following: \"" .. table.concat(util.keys(Enums.Conventions), "\",\"") .. "\"");
	end
	
	self.parser = Parser:new({
		luaVersion = luaVersion;
	});
	self.unparser = Unparser:new({
		luaVersion = luaVersion;
	});
	self.conventions = conventions;
end

function Pipeline:getLuaVersion()
	return self.luaVersion;
end

function Pipeline:setNameGenerator(nameGenerator)
	if type(nameGenerator) == "string" then
		local resolved = Pipeline.NameGenerators[nameGenerator];
		if not resolved then
			local available = {};
			for k in pairs(Pipeline.NameGenerators) do
				available[#available + 1] = k;
			end
			table.sort(available);
			logger:error(string.format(
				"NameGenerator \"%s\" not found. Available: %s",
				nameGenerator, table.concat(available, ", ")
			));
		end
		nameGenerator = resolved;
	end

	if type(nameGenerator) == "function" or type(nameGenerator) == "table" then
		self.namegenerator = nameGenerator;
	else
		logger:error("setNameGenerator: argument must be a generator name string or a generator table");
	end
end

function Pipeline:apply(code, filename)
	local startTime = gettime();
	filename = filename or "Anonymus Script";
	logger:info(string.format("Processing %s ...", filename));
	-- Seed the Random Generator
	if(self.Seed > 0) then
		math.randomseed(self.Seed);
	else
		math.randomseed(os.time())
	end
	
	logger:info("Parsing ...");
	local parserStartTime = gettime();

	local sourceLen = string.len(code);
	local ast = self.parser:parse(code);

	local parserTimeDiff = gettime() - parserStartTime;
	logger:info(string.format("Parsing Done in %.2f seconds", parserTimeDiff));
	
	-- User Defined Steps
	for i, step in ipairs(self.steps) do
		local stepStartTime = gettime();
		logger:info(string.format("Step: %s", step.Name or "unnamed"));
		local newAst = step:apply(ast, self);
		if type(newAst) == "table" then
			ast = newAst;
		end
		logger:info(string.format("Step done in %.2f seconds", gettime() - stepStartTime));
	end
	
	-- Rename Variables Step
	self:renameVariables(ast);
	
	code = self:unparse(ast);
	
	-- Post-unparse: VariableRenamer (runs before compression passes)
	if self._varRenamerStep then
		logger:info("Running VariableRenamer post-pass ...")
		code = self._varRenamerStep:process(code)
		logger:info("VariableRenamer done.")
	end

	-- Post-unparse: BytecodeEncoder (runs before compression passes)
	if self._bytecodeEncoderStep then
		logger:info("Running BytecodeEncoder post-pass ...")
		code = self._bytecodeEncoderStep:process(code)
		logger:info("BytecodeEncoder done.")
	end

	-- Post-unparse compression (if Compressor step was used)
	if self._compressorStep then
		logger:info("Running Compressor post-pass ...");
		local preLen = #code;
		code = self._compressorStep:compressSource(code);
		logger:info(string.format("Compressed %.1f%% -> %.1f%% of input", (preLen/sourceLen)*100, (#code/sourceLen)*100));
	end

	-- Post-unparse LZW blob compression (if BlobCompress step was used)
	if self._blobCompressStep then
		logger:info("Running BlobCompress post-pass ...");
		local preLen = #code;
		code = self._blobCompressStep:compressSource(code);
		logger:info(string.format("BlobCompress: %.1f%% -> %.1f%% of input", (preLen/sourceLen)*100, (#code/sourceLen)*100));
	end

	-- Post-unparse CrewmateFormat pass — runs after all compression so the
	-- whitespace padding is not stripped away by Compressor/BlobCompress.
	-- Must run BEFORE ZukaZalgo so Zalgo marks stack on top of the shape.
	if self._crewmateFormatStep then
		logger:info("Running CrewmateFormat post-pass ...");
		code = self._crewmateFormatStep:process(code);
		logger:info("CrewmateFormat done.");
	end

	-- Post-unparse Zalgo pass — MUST run after BlobCompress so combining marks
	-- are not compressed away.  ZukaZalgo registers itself here via :apply().
	if self._zalgoStep then
		logger:info("Running ZukaZalgo post-pass ...");
		code = self._zalgoStep:process(code);
		logger:info("ZukaZalgo done.");
	end
	
	local timeDiff = gettime() - startTime;
	logger:info(string.format("Done in %.2f seconds", timeDiff));
	
	logger:info(string.format("Output size is %.2f%% of input size", (string.len(code) / sourceLen)*100))
	
	return code;
end

function Pipeline:unparse(ast)
	local startTime = gettime();
	logger:info("Generating output ...");
	
	local unparsed = self.unparser:unparse(ast);
	
	local timeDiff = gettime() - startTime;
	logger:info(string.format("Output generated in %.2f seconds", timeDiff));
	
	return unparsed;
end

function Pipeline:renameVariables(ast)
	local startTime = gettime();
	logger:info("Renaming ...");
	
	
	local generatorFunction = self.namegenerator or Pipeline.NameGenerators.Mangled;
	if(type(generatorFunction) == "table") then
		if (type(generatorFunction.prepare) == "function") then
			generatorFunction.prepare(ast);
		end
		generatorFunction = generatorFunction.generateName;
	end
	
	if not self.unparser:isValidIdentifier(self.VarNamePrefix) and #self.VarNamePrefix ~= 0 then
		logger:error(string.format("The Prefix \"%s\" is not a valid Identifier in %s", self.VarNamePrefix, self.LuaVersion));
	end

	local globalScope = ast.globalScope;
	globalScope:renameVariables({
		Keywords = self.conventions.Keywords;
		generateName = generatorFunction;
		prefix = self.VarNamePrefix;
	});
	
	local timeDiff = gettime() - startTime;
	logger:info(string.format("Renaming done in %.2f seconds", timeDiff));
end




return Pipeline;