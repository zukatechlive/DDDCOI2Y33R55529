-- ZukaTech Obfuscator — namegenerators/number.lua
-- Fixed: replaced all bit.bxor calls with pure Lua 5.1 compatible bitwise XOR.

local util = require("ZukaTech.util")

-- ────────────────────────────────────────────────
-- Config
-- ────────────────────────────────────────────────

local PREFIX     = "_zuka"
local MIN_LENGTH = 5

-- "hex"    → _a3f0c1
-- "base36" → _k4z9mq
-- "hash"   → _f7c3a1b0  (default, looks structureless)
local MODE = "hash"

-- ────────────────────────────────────────────────
-- Pure Lua 5.1 Bitwise XOR
-- ────────────────────────────────────────────────

--- XOR two non-negative integers without the bit library.
--- Works by iterating through bits manually.
---@param a number
---@param b number
---@return number
local function bxor(a, b)
    local result = 0
    local bit    = 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then
            result = result + bit
        end
        a   = math.floor(a / 2)
        b   = math.floor(b / 2)
        bit = bit * 2
    end
    return result
end

-- ────────────────────────────────────────────────
-- Per-run State
-- ────────────────────────────────────────────────

local salt      = 0
local xorKey    = 0
local base36Map = {}

-- ────────────────────────────────────────────────
-- Internal Encoders
-- ────────────────────────────────────────────────

---@param id number
---@return string
local function encodeHex(id)
    local v = bxor((id + salt) % 0xFFFFFFFF, xorKey) % 0xFFFFFFFF
    local h = string.format("%x", v)
    while #h < MIN_LENGTH do h = "0" .. h end
    return h
end

---@param id number
---@return string
local function encodeBase36(id)
    local v    = bxor((id + salt) % 0xFFFFFFFF, xorKey) % 0xFFFFFFFF
    local name = ""

    repeat
        local d = v % 36
        v       = math.floor(v / 36)
        name    = base36Map[d + 1] .. name
    until v == 0

    while #name < MIN_LENGTH do
        name = base36Map[1] .. name
    end

    return name
end

---@param id number
---@return string
local function encodeHash(id)
    local h = bxor(0x811C9DC5, salt)
    local v = (id + xorKey) % 0xFFFFFFFF

    for _ = 1, 4 do
        h = bxor(h, v % 0xFF)
        h = (h * 0x01000193) % 0xFFFFFFFF
        v = (v * 1664525 + 1013904223) % 0xFFFFFFFF
    end

    local result = string.format("%x", h)
    while #result < MIN_LENGTH do result = "0" .. result end
    return result
end

-- ────────────────────────────────────────────────
-- Dispatch
-- ────────────────────────────────────────────────

local encoders = {
    hex    = encodeHex,
    base36 = encodeBase36,
    hash   = encodeHash,
}

-- ────────────────────────────────────────────────
-- Public
-- ────────────────────────────────────────────────

local function generateName(id, scope)
    local encode = encoders[MODE] or encodeHash
    return PREFIX .. encode(id)
end

local function prepare(ast)
    salt   = math.random(0, 0xFFFFFF)   -- kept under 2^24 to stay safe
    xorKey = math.random(0, 0xFFFFFF)   -- from float precision issues

    local chars = {}
    for i = 0, 9  do chars[i + 1]  = tostring(i) end
    for i = 0, 25 do chars[i + 11] = string.char(97 + i) end
    util.shuffle(chars)
    base36Map = chars
end

return {
    generateName = generateName,
    prepare      = prepare,
}