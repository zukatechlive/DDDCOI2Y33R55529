-- presets.lua — ZukaCLI Overhauled Presets
--
-- All presets rebuilt from scratch for guaranteed successful executor output.
--
-- EXECUTOR COMPATIBILITY RULES applied across every preset:
--   1. ExecutorGuard ALWAYS runs first (before any Vmify pass).
--   2. PcallSilencer mode="forward" — never "noop". Noop breaks executor
--      coroutines that rely on pcall returning real errors internally.
--   3. AntiDump GCInterval kept <= 120. Higher values stall low-memory
--      executors (mobile, Wine) during the GC pressure loop.
--   4. VirtualGlobals UseNumericKeys=true — string key proxies are more
--      likely to collide with executor metatable hooks on _G.
--   5. DynamicXOR Treshold kept <= 0.6 inside VM passes. Higher values
--      cause redundant XOR chains that trip Synapse/Fluxus constant limits.
--   6. ConstantArray LocalWrapperArgCount <= 12. Executors cap vararg
--      spread; above 12 args causes silent truncation on some VMs.
--   7. OpaquePredicates InjectionsPerBlock <= 3. Above 3, some executors
--      hit instruction count limits per block under their VM interpreter.
--   8. JunkStatements InjectionCount <= 4, ChainLength <= 5.
--      Aggressive junk overwhelms the executor script scheduler on scripts
--      that already have large constant pools from Vmify.
--   9. ShadowRegisters ShadowSize <= 40. Executor Lua stacks are capped;
--      large shadow pools risk stack overflow on deeply-nested scripts.
--  10. Compressor/BlobCompress placed dead last — never before any AST pass.
--  11. WrapInFunction always second-to-last (before compressor only).
--  12. AntiTamper UseDebug=false — debug.sethook is not available in most
--      executor environments; true causes immediate self-kill on load.
--
-- PRESET TIERS:
--   Fast        — single-pass, minimal overhead. Drop-in for hot paths.
--   Light       — light obfuscation, no VM. Fast executor load time.
--   Standard    — single Vmify + string/constant hardening. Daily driver.
--   Executor    — executor-tuned, full defense stack, single VM pass.
--   Strong      — double Vmify with integrity layer. High strength.
--   Max         — triple-layer, all defenses. Slowest load, hardest to read.
--   BytecodeMax — VmifyBC custom bytecode backend. Unique opcode layout.
--   NoVM        — no Vmify at all. Pure source-level. Executor-safe fallback.
--   HttpGet     — minimal, string-safe. For loadstring(game:HttpGet(...)).
--   Debug       — VmifyBC passthrough only. Dev/test use.
--   Small       — InvertedExecution only. Tiny output footprint.
--   Strings     — string encryption only. For patching live scripts.
--   Luraph      — mirrors Luraph obfuscator output pattern.
--   Luarmor     — mirrors Luarmor obfuscator output pattern.
--   ZuraphMax   — maximum InvertedExecution + full stack. Flagship.
--   Tier1       — Vmify + IntegrityHash chain. Anti-decompile focused.
--   Tier1_BC    — VmifyBC + CffIntegrity chain. Bytecode anti-dump focused.
--   Main        — double Vmify + ShadowRegisters. Production standard.

return {

-- ============================================================
-- Fast — single pass, minimal runtime overhead
-- Use when load speed matters more than obfuscation depth.
-- ============================================================
["Fast"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
       -- { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = false; MinInterval = 10; MaxInterval = 20; GlobalScanCount = 6 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.3 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Light — source-level only, no VM, fast executor startup
-- ============================================================
["Light"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "SegAddr";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 12; MaxInterval = 22; GlobalScanCount = 7 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.8; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.5; InternalTreshold = 0.15 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Standard — single Vmify, full constant/string hardening
-- Daily-driver preset. Reliable on all major executors.
-- ============================================================
["Standard"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Luraph";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        --{ Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 1 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.65; InjectionsPerBlock = 2 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Executor — executor-tuned, full defense, single VM pass
-- All checks executor-safe. Recommended for public releases.
-- ============================================================
["Executor"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "ZukaZalgo";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 25; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.65; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.8; TableWriteRatio = 0.5;
            ChainLength = 3; TableWriteCount = 3;
        } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Strong — double Vmify with integrity validation layer
-- Significantly harder to decompile. Moderate load overhead.
-- ============================================================
["Strong"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "SegAddr";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 10 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "IntegrityHash";        Settings = { SampleSize = 16; UseFakeExec = true } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.8; Rounds = 4 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 1 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.7; LocalWrapperCount = 3; LocalWrapperArgCount = 10;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.25 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.75; InjectionsPerBlock = 2 } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Max — triple-layer, every defense active
-- Hardest to reverse. Highest load time. Use for finals/releases.
-- ============================================================
["Max"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 8; MaxInterval = 20; GlobalScanCount = 12 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "HookDetection";        Settings = { CheckGlobals = true; CheckUpvalues = true } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.9; Rounds = 6 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
       -- { Name = "IntegrityHash";        Settings = { SampleSize = 20; UseFakeExec = false} };
        { Name = "ShadowRegisters";      Settings = { Density = 0.35; ShadowSize = 28 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        --{ Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.35; InjectionsPerBlock = 1 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 1; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 2; TableWriteCount = 3;
        } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.40 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- BytecodeMax — VmifyBC custom bytecode engine + full stack
-- Unique per-compile opcode layout. Hardest to statically analyze.
-- ============================================================
["BytecodeMax"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Il";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 10 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "CffIntegrity";         Settings = { TableSize = 9; TrapIndex = 0 } };
        { Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.35 } };
        { Name = "ShadowRegisters";      Settings = { Density = 0.30; ShadowSize = 24 } };
        { Name = "VmifyBC";              Settings = { XorKey = 0; ShuffleOpcodes = true } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.80; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 3; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "BlobCompress";         Settings = { MinInputBytes = 900; MinGainPct = 5 } };
    };
    Hercules = nil;
};

-- ============================================================
-- NoVM — no Vmify at all, pure source-level obfuscation
-- Executor-safe fallback when VM output triggers detections.
-- ============================================================
["NoVM"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "DecEsc";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 12; MaxInterval = 24; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 6; MinAbsValue = 3;
        } };
        { Name = "ShadowRegisters";      Settings = { Density = 0.35; ShadowSize = 24 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.75 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.70; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 3; Treshold = 0.80; TableWriteRatio = 0.5;
            ChainLength = 3; TableWriteCount = 3;
        } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.30 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- HttpGet — loadstring(game:HttpGet(url)) safe
-- Minimal stack. No VM quirks. Strings fully encrypted.
-- ============================================================
["HttpGet"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = false; MinInterval = 10; MaxInterval = 20; GlobalScanCount = 6 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 1 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.65; TableWriteRatio = 0.4;
            ChainLength = 2; TableWriteCount = 2;
        } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Strings — string encryption pass only
-- For patching or wrapping an already-obfuscated script.
-- ============================================================
["Strings"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = true;
    Seed          = 0;
    Steps = {
        { Name = "EncryptStrings"; Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Small — InvertedExecution only, minimal footprint
-- Tiny output. Useful for loader stubs or injectors.
-- ============================================================
["Small"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = true;
    Seed          = 0;
    Steps = {
        { Name = "InvertedExecution"; Settings = { ChunkSize = 1; RandomiseIds = true; JunkChunks = 3 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Debug — VmifyBC passthrough only. Dev/test.
-- ============================================================
["Debug"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Boronide";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "VmifyBC";        Settings = { XorKey = 0; ShuffleOpcodes = true } };
		{ Name = "DynamicXOR";           Settings = { Treshold = 0.30 } };

		{ Name = "DynamicDecrypt";       Settings = { Threshold = 0.8; Rounds = 4 } };
		{ Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "WrapInFunction"; Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Luraph — mirrors Luraph obfuscator output pattern
-- ============================================================
["Luraph"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Luraph";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
	    { Name = "InvertedExecution";    Settings = { ChunkSize = 2; RandomiseIds = true; JunkChunks = 2 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.30 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
		{ Name = "DynamicDecrypt";       Settings = { Threshold = 0.8; Rounds = 4 } };
		{ Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Luarmor — mirrors Luarmor obfuscator output pattern
-- ============================================================
["Luarmor"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 3; Treshold = 0.80; TableWriteRatio = 0.5;
            ChainLength = 3; TableWriteCount = 3;
        } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- ZuraphMax — flagship: InvertedExecution + full defense stack
-- ============================================================
["ZuraphMax"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 8; MaxInterval = 20; GlobalScanCount = 10 } };
        { Name = "InvertedExecution";    Settings = { ChunkSize = 2; RandomiseIds = true; JunkChunks = 2 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.45 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 7; MinAbsValue = 4;
        } };
        { Name = "ShadowRegisters";      Settings = { Density = 0.35; ShadowSize = 28 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.40 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Tier1 — Vmify + IntegrityHash chain, anti-decompile focus
-- ============================================================
["Tier1"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Func";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "IntegrityHash";        Settings = { SampleSize = 16; UseFakeExec = true } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 1 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Tier1_BC — VmifyBC bytecode engine + CffIntegrity chain
-- Anti-dump focused. Unique opcode table per compile.
-- ============================================================
["Tier1_BC"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Il";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "CffIntegrity";         Settings = { TableSize = 7; TrapIndex = 0 } };
        { Name = "XorTable";             Settings = { ShuffleTable = true; ReplaceBit32 = true } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.25 } };
        { Name = "ShadowRegisters";      Settings = { Density = 0.30; ShadowSize = 24 } };
        { Name = "VmifyBC";              Settings = { XorKey = 0; ShuffleOpcodes = true } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "BlobCompress";         Settings = { MinInputBytes = 900; MinGainPct = 5 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Main — double Vmify + ShadowRegisters. Production standard.
-- ============================================================
["Main"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Il";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 10 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "ShadowRegisters";      Settings = { Density = 0.30; ShadowSize = 24 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 1 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.80; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "AntiDump";             Settings = { GCInterval = 60 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

-- ============================================================
-- Default — lightweight rename + constant shuffle
-- Legacy compat. For scripts that only need basic renaming.
-- ============================================================
["Default"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "_z";
    NameGenerator = "SegAddr";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = false; MinInterval = 10; MaxInterval = 20; GlobalScanCount = 6 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.2 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.75; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 5;
        } };
        { Name = "InvertedExecution";    Settings = { ChunkSize = 1; RandomiseIds = true; JunkChunks = 4 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- ============================================================
-- Medium — Vmify + ConstantArray, mid-tier
-- ============================================================
["Medium"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "ZukaZalgo";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 7 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "Vmify";                Settings = { OptimizationLevel = 1 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};

-- Alias: "1" kept for legacy CLI calls that use --preset 1
["1"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.9; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.75; PoolSize = 48; MinStatements = 2 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.8; TableWriteRatio = 0.5;
            ChainLength = 3; TableWriteCount = 3;
        } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};

}
