@echo off
title ZukaCLI — Strong
set /p target=Drag script here (or type path): 

echo.
set /p luau_choice=Enable LuaU mode? (y/n, default=n): 

set opt=
if /i "%luau_choice%"=="y" (
    set opt=--LuaU
)

echo.
echo Executing: .\lua.exe cli.lua --preset Strong %opt% %target%
echo ---------------------------------------------------------
.\lua.exe cli.lua --preset Strong %opt% %target%
echo ---------------------------------------------------------
echo.
echo Done.
pause
