print("by zuka")

