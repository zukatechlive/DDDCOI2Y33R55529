-- Obfuscation Step: Hook Detection (v4)
--
-- FIX SUMMARY vs v3:
--   * dumpProbe: wrapped string.dump call now correctly type-checks _wv before
--     passing to string.dump. In Luau, string.dump on a non-function value
--     raises an error that escapes the pcall context since the arg-check
--     happens before the C boundary in some builds. Guard with type().
--   * dumpProbe logic fixed: pcall returns (true, result) on success.
--     string.dump SUCCEEDS on Lua functions (hooked wrappers) and FAILS on
--     C functions (genuine natives). So kill when pcall returns TRUE (dump
--     succeeded = it's a Lua function pretending to be a native).
--   * Whitelist narrowed further: removed 'error' and 'type' — in Luau
--     these are sometimes tagged as "Lua" builtins, not "C", causing
--     false-positive kills on clean executors (Wave, Solara, etc).
--   * Upvalue check rewritten: debug.getupvalue on a C function returns nil
--     for the name in Luau — no error is raised. The old pcall-wrapped check
--     was therefore always "ok=true, name=nil" which broke the loop logic.
--     New check: call directly (no pcall needed), break on nil name,
--     only kill if name is a non-empty string (named upvalue = Lua wrapper).
--   * Kill path unchanged: task.defer + infinite task.wait (silent, uncatchable).

local Step   = require("ZukaTech.step")
local Ast    = require("ZukaTech.ast")
local Parser = require("ZukaTech.parser")
local Enums  = require("ZukaTech.enums")

local LuaVersion = Enums.LuaVersion

local HookDetection       = Step:extend()
HookDetection.Description = "Hook detection via string.dump probes + what==\"C\" checks. False-positive safe on Roblox executors."
HookDetection.Name        = "Hook Detection"

HookDetection.SettingsDescriptor = {
    CheckDump = {
        type        = "boolean",
        default     = true,
        description = "Use string.dump to detect Lua-wrapper replacements of native functions.",
    },
    CheckUpvalues = {
        type        = "boolean",
        default     = true,
        description = "Check debug.getupvalue for named upvalues on debug.getinfo (indicates Lua wrapper).",
    },
}

function HookDetection:init(settings) end

function HookDetection:apply(ast, pipeline)
    local checkDump     = self.CheckDump
    local checkUpvalues = self.CheckUpvalues

    local fnKill    = "_hk" .. math.random(10000, 99999)
    local fnGuard   = "_hg" .. math.random(10000, 99999)
    local varPcall  = "_hp" .. math.random(10000, 99999)
    local varDump   = "_hd" .. math.random(10000, 99999)
    local varDbg    = "_hb" .. math.random(10000, 99999)
    local varTbl    = "_ht" .. math.random(10000, 99999)

    -- Only probe functions that are guaranteed C natives in unmodified Luau.
    -- Removed: error, type (can be "Lua"-tagged in some Luau builds).
    -- Removed: pairs, ipairs, rawget, rawset (never hooked, false positives).
    local whitelistEntries = string.format([[
    local %s = {
        _dbgi = %s["getinfo"],
        _dbgu = %s["getupvalue"],
        _pc   = pcall,
    }]], varTbl, varDbg, varDbg)

    -- dumpProbe: string.dump succeeds on Lua functions (= hooked wrapper).
    -- Guards: (1) type-check before dump so we don't error on non-functions,
    --         (2) kill when _dok is TRUE (dump worked = it's a Lua fn, not C).
    local dumpProbe = ""
    if checkDump then
        dumpProbe = string.format([[
        if type(_wv) == "function" then
            local _dok = %s(%s, _wv)
            if _dok then %s() end
        end
]], varPcall, varDump, fnKill)
    end

    local whitelistLoop = string.format([[
    for _wk, _wv in next, %s do
        local _wi = %s["getinfo"](_wv)
        if not _wi or _wi["what"] ~= "C" then %s() end
        %s
    end
]], varTbl, varDbg, fnKill, dumpProbe)

    -- Upvalue check: no pcall needed — getupvalue on a C fn returns nil
    -- for the name without throwing. Kill only on a non-empty string name
    -- (empty string is Luau's sentinel for unnamed upvalues in Lua closures
    -- that aren't actual hooks).
    local upvalueCode = ""
    if checkUpvalues then
        upvalueCode = string.format([[
    do
        local _ui = 1
        while true do
            local _un = %s["getupvalue"](%s["getinfo"], _ui)
            if _un == nil then break end
            if type(_un) == "string" and #_un > 0 then %s() end
            _ui = _ui + 1
        end
    end
]], varDbg, varDbg, fnKill)
    end

    local code = string.format([[
do
    local function %s()
        task.defer(function() while true do task.wait(1e9) end end)
        while true do task.wait(1e9) end
    end

    local function %s()
        local %s = pcall
        local %s = string.dump
        local %s = debug

        -- Sanity: confirm debug.getinfo itself is still a C function
        local _di = %s["getinfo"](%s["getinfo"])
        if not _di or _di["what"] ~= "C" then %s() end

        %s
        %s
        %s
    end

    %s()
end
]],
        fnKill,
        fnGuard,
        varPcall, varDump, varDbg,
        varDbg, varDbg, fnKill,
        whitelistEntries,
        whitelistLoop,
        upvalueCode,
        fnGuard
    )

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(code) end)
    if not ok then return ast end

    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    return ast
end

return HookDetection
