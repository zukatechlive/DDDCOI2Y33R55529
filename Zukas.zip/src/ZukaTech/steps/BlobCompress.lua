-- This Script is Part of the ZukaTech Obfuscator
--
-- BlobCompress.lua  (base85 edition)
--
-- Encodes the final source into an ASCII85 blob stored in a [=[ ]=] string.
-- Produces the visually noisy !<=> style output matching the target obfuscator.
--
-- Design:
--   • No z-abbreviation — blob length is always an exact multiple of 5,
--     which makes the runtime decoder a dead-simple numeric loop.
--   • Pad count (0-3) stored as a single prefix char so the decoder knows
--     how many trailing bytes to drop: chr(33+pad) prepended to the blob.
--   • Runtime decoder is plain, explicit Lua — no metatable tricks,
--     no gsub pattern abuse, no string.unpack (Lua 5.1 compat).

local Step   = require("ZukaTech.step")
local logger = require("logger")

local BlobCompress       = Step:extend()
BlobCompress.Description = "Base85 encodes the final output into a [=[ ]=] blob with a simple runtime decoder. Executor-safe, Lua 5.1 compatible."
BlobCompress.Name        = "Blob Compress"

BlobCompress.SettingsDescriptor = {
    MinInputBytes = {
        name        = "MinInputBytes",
        description = "Skip encoding if input is smaller than this many bytes",
        type        = "number",
        default     = 200,
        min         = 0,
        max         = 1e9,
    },
    MinGainPct = {
        name        = "MinGainPct",
        description = "Skip if output would be larger than input by more than this percent (0 = always run)",
        type        = "number",
        default     = 0,
        min         = 0,
        max         = 100,
    },
}

function BlobCompress:init() end

-- ── Encoder ───────────────────────────────────────────────────────────────────

local function encodeBase85(data)
    -- Pad to a multiple of 4 with NUL bytes
    local pad = (4 - (#data % 4)) % 4
    for _ = 1, pad do data = data .. "\0" end

    local out = { string.char(33 + pad) }  -- prefix: pad count as '!'..'$'

    for i = 1, #data, 4 do
        local b1 = data:byte(i)   or 0
        local b2 = data:byte(i+1) or 0
        local b3 = data:byte(i+2) or 0
        local b4 = data:byte(i+3) or 0
        local n  = b1 * 16777216 + b2 * 65536 + b3 * 256 + b4

        local c5 = string.char((n % 85) + 33); n = math.floor(n / 85)
        local c4 = string.char((n % 85) + 33); n = math.floor(n / 85)
        local c3 = string.char((n % 85) + 33); n = math.floor(n / 85)
        local c2 = string.char((n % 85) + 33); n = math.floor(n / 85)
        local c1 = string.char((n % 85) + 33)
        out[#out + 1] = c1 .. c2 .. c3 .. c4 .. c5
    end

    return table.concat(out)
end

-- ── Long-string wrapper ───────────────────────────────────────────────────────

local function longStr(s)
    local level = 0
    while s:find("]" .. string.rep("=", level) .. "]", 1, true) do
        level = level + 1
    end
    local eq = string.rep("=", level)
    return "[" .. eq .. "[" .. s .. "]" .. eq .. "]"
end

-- ── Runtime decoder ───────────────────────────────────────────────────────────
-- Plain explicit loop — no metatable tricks, no string.unpack, Lua 5.1 safe.
-- One-liner so decoded script errors report accurate line numbers.

local DECODER = [[local __b={BLOB};local __p=string.byte(__b,1)-33;local __o={};for __i=2,#__b,5 do local __a=string.byte(__b,__i) or 0;local __c=string.byte(__b,__i+1) or 0;local __d=string.byte(__b,__i+2) or 0;local __e=string.byte(__b,__i+3) or 0;local __f=string.byte(__b,__i+4) or 0;local __n=(__a-33)*52200625+(__c-33)*614125+(__d-33)*7225+(__e-33)*85+(__f-33);__o[#__o+1]=string.char(math.floor(__n/16777216)%256,math.floor(__n/65536)%256,math.floor(__n/256)%256,__n%256);end;local __s=table.concat(__o);if __p>0 then __s=__s:sub(1,#__s-__p)end;(loadstring or load)(__s)()]]

-- ── compressSource ────────────────────────────────────────────────────────────

function BlobCompress:compressSource(source)
    local minBytes = self.MinInputBytes or 200
    local minGain  = (self.MinGainPct   or 0) / 100

    if #source < minBytes then
        logger:info(string.format(
            "[BlobCompress] Skipped: input %d bytes < MinInputBytes %d",
            #source, minBytes))
        return source
    end

    local blob    = encodeBase85(source)
    local blobLit = longStr(blob)

    -- % in gsub replacement is an escape prefix — double all % in the literal
    local safeLit = blobLit:gsub("%%", "%%%%")
    local output  = DECODER:gsub("{BLOB}", safeLit)

    local gain = 1 - (#output / #source)
    if gain < minGain then
        logger:info(string.format(
            "[BlobCompress] Skipped: output is %.1f%% of input size",
            (#output / #source) * 100))
        return source
    end

    logger:info(string.format(
        "[BlobCompress] %d -> %d bytes (%.1f%% of input)",
        #source, #output, (#output / #source) * 100))

    return output
end

-- ── Step interface ────────────────────────────────────────────────────────────

function BlobCompress:apply(ast, pipeline)
    if pipeline._blobCompressStep then
        logger:warn("[BlobCompress] Multiple BlobCompress steps detected; only the last one will run.")
    end
    pipeline._blobCompressStep = self
    return ast
end

return BlobCompress