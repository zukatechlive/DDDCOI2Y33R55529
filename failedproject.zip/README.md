# Zuka Obfuscator Bot — Setup Guide

## Your folder should look like this when done:

```
zuka-bot/
├── index.js
├── package.json
├── .env
└── obfuscator/         ← paste your entire obfuscator folder here
    ├── lua.exe
    ├── lua5.1.dll
    ├── lua51.dll
    ├── lua5.1.dll.manifest
    ├── cli.lua
    ├── src/
    └── ...
```

---

## Step 1 — Install Node.js
Download and install from: https://nodejs.org  
Choose the "LTS" version.

---

## Step 2 — Set up the bot folder
1. Put this entire `zuka-bot` folder somewhere on your PC
2. Inside it, create a folder called `obfuscator`
3. Copy everything from your Zuka obfuscator into that `obfuscator` folder
   (lua.exe, cli.lua, src/, all dlls, etc.)

---

## Step 3 — Add your token
1. Open `.env` in Notepad
2. Replace `paste_your_bot_token_here` with your actual bot token
3. Save the file

---

## Step 4 — Install dependencies
1. Open the `zuka-bot` folder
2. Click the address bar at the top, type `cmd`, press Enter
3. In the black window that opens, type:
   ```
   npm install
   ```
4. Wait for it to finish

---

## Step 5 — Run the bot
In that same black window, type:
```
node index.js
```

You should see:
```
✓ Logged in as YourBot#1234
✓ Zuka Bot is online!
```

---

## How to use in Discord

| Command | What it does |
|---|---|
| `!help` | Shows all commands |
| `!obfuscate print("hi")` | Obfuscates typed code |
| `!obfuscate` + attach .lua file | Obfuscates a file |
| `!obfuscate --preset Strong print("hi")` | Use a specific preset |
| `!obfuscate --preset ZuraphMax --luau` + file | LuaU mode with preset |

## Presets
`Minify` `Weak` `Medium` `Strong` `Tier1` `ZuraphMax` `HttpGet` `NoVmMax`

---

## To keep the bot running 24/7
Look into free hosting options like:
- **Railway** (https://railway.app) — free tier available
- **Render** (https://render.com) — free tier available
Note: You'll need to upload your obfuscator files there too, and use a Linux lua binary instead of lua.exe
