return {
["Default"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Luraph";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.9; InternalTreshold = 0.2 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.75; PoolSize = 48; MinStatements = 2 } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 7; MinAbsValue = 4;
        } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["VmifyBC"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Luraph";
    PrettyPrint   = false;
    Seed   = 0;
    Steps = {
       { Name = "EncryptStrings"; Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
       { Name = "VmifyBC";              Settings = { XorKey = 0; ShuffleOpcodes = true } };
    };
    Hercules = nil;
};
["Strings"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Rblx";
    PrettyPrint   = true;
    Seed          = 0;
    Steps = {
        { Name = "EncryptStrings"; Settings = {} };
    };
    Hercules = nil;
};
["HttpGet"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Luraph";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 3 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.65; TableWriteRatio = 0.4;
            ChainLength = 2; TableWriteCount = 2;
        } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};
}
