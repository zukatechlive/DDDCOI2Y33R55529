const { Client, GatewayIntentBits, AttachmentBuilder } = require("discord.js")
const { execFile } = require("child_process")
const fs = require("fs")
const path = require("path")
const os = require("os")
const https = require("https")
require("dotenv").config()

// ── Config ────────────────────────────────────────────────────────────────
const LUA_EXE = path.join(__dirname, "obfuscator", "lua.exe")
const CLI_LUA = path.join(__dirname, "obfuscator", "cli.lua")
const OBF_DIR = path.join(__dirname, "obfuscator")

const VALID_PRESETS = ["Default", "VmifyBC", "Strings", "HttpGet"]

// ── Obfuscate function ────────────────────────────────────────────────────
function obfuscate(code, preset, luau) {
    return new Promise((resolve, reject) => {
        const tmpInput = path.join(os.tmpdir(), `zuka_${Date.now()}.lua`)
        const tmpOutput = tmpInput.replace(".lua", ".obfuscated.lua")

        fs.writeFileSync(tmpInput, code, "utf8")

        const args = [CLI_LUA, "--preset", preset, "--out", tmpOutput]
        if (luau) args.push("--LuaU")
        args.push(tmpInput)

        execFile(LUA_EXE, args, { cwd: OBF_DIR }, (err, stdout, stderr) => {
            // Cleanup input
            if (fs.existsSync(tmpInput)) fs.unlinkSync(tmpInput)

            if (err) {
                if (fs.existsSync(tmpOutput)) fs.unlinkSync(tmpOutput)
                return reject(stderr || err.message)
            }

            if (fs.existsSync(tmpOutput)) {
                const result = fs.readFileSync(tmpOutput, "utf8")
                fs.unlinkSync(tmpOutput)
                resolve(result)
            } else {
                reject("Obfuscator ran but produced no output file.")
            }
        })
    })
}

// ── Download helper ───────────────────────────────────────────────────────
function downloadText(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (res) => {
            let data = ""
            res.on("data", (chunk) => (data += chunk))
            res.on("end", () => resolve(data))
            res.on("error", reject)
        })
    })
}

// ── Bot setup ─────────────────────────────────────────────────────────────
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
})

client.once("ready", () => {
    console.log(`✓ Logged in as ${client.user.tag}`)
    console.log(`✓ Zuka Bot is online!`)
})

// ── Message handler ───────────────────────────────────────────────────────
client.on("messageCreate", async (message) => {
    if (message.author.bot) return

    const content = message.content.trim()

    // ── !help ──────────────────────────────────────────────────────────────
    if (content === "!help") {
        return message.reply([
            "**Zuka Obfuscator Bot**",
            "",
            "**Commands:**",
            "`!obfuscate <code>` — Obfuscate code directly",
            "`!obfuscate` + attach a `.lua` file — Obfuscate a file",
            "",
            "**Options (add to command):**",
            "`--preset <name>` — Choose preset (default: Default)",
            "`--luau` — Enable LuaU mode",
            "",
            "**Presets:**",
            "`Default` — Full obfuscation with VM, encryption, anti-tamper & more",
            "`VmifyBC` — Bytecode VM obfuscation with string encryption",
            "`Strings` — String encryption only (lightweight)",
            "`HttpGet` — Executor-safe with VM and junk statements",
            "",
            "**Examples:**",
            "`!obfuscate print('hi')`",
            "`!obfuscate --preset Strings print('hi')`",
            "`!obfuscate --preset HttpGet --luau` (with attached .lua file)",
        ].join("\n"))
    }

    // ── !obfuscate ─────────────────────────────────────────────────────────
    if (!content.startsWith("!obfuscate")) return

    // Parse args from message
    let raw = content.replace("!obfuscate", "").trim()

    let preset = "Default"
    let luau = false

    // Extract --preset
    const presetMatch = raw.match(/--preset\s+(\S+)/i)
    if (presetMatch) {
        const requested = presetMatch[1]
        if (!VALID_PRESETS.includes(requested)) {
            return message.reply(`❌ Unknown preset \`${requested}\`.\nValid presets: ${VALID_PRESETS.join(", ")}`)
        }
        preset = requested
        raw = raw.replace(presetMatch[0], "").trim()
    }

    // Extract --luau
    if (/--luau/i.test(raw)) {
        luau = true
        raw = raw.replace(/--luau/i, "").trim()
    }

    // Strip code block fences
    let code = raw.replace(/^```(?:lua)?\n?/, "").replace(/```$/, "").trim()

    // Check for file attachment
    const attachment = message.attachments.find((a) => a.name.endsWith(".lua"))
    if (attachment) {
        try {
            code = await downloadText(attachment.url)
        } catch {
            return message.reply("❌ Failed to download your file.")
        }
    }

    if (!code) {
        return message.reply([
            "❌ No code provided!",
            "Usage: `!obfuscate <code>` or attach a `.lua` file.",
            "Type `!help` for more info.",
        ].join("\n"))
    }

    const statusMsg = await message.reply(`⏳ Obfuscating with preset \`${preset}\`${luau ? " (LuaU mode)" : ""}...`)

    try {
        const result = await obfuscate(code, preset, luau)

        // Send as code block if short enough, otherwise as file
        if (result.length < 1800) {
            await statusMsg.edit(`✅ Done! Preset: \`${preset}\`\n\`\`\`lua\n${result}\n\`\`\``)
        } else {
            const outName = attachment ? `obf_${attachment.name}` : `obfuscated.lua`
            const tmpOut = path.join(os.tmpdir(), outName)
            fs.writeFileSync(tmpOut, result, "utf8")

            const file = new AttachmentBuilder(tmpOut, { name: outName })
            await statusMsg.edit({ content: `✅ Done! Preset: \`${preset}\``, files: [file] })
            fs.unlinkSync(tmpOut)
        }
  } catch (err) {
        console.error(err)
        await statusMsg.edit(`❌ Obfuscation failed. Please check your code and try again.`)
    }
})

// ── Start ─────────────────────────────────────────────────────────────────
if (!process.env.TOKEN) {
    console.error("ERROR: No TOKEN found in .env file!")
    process.exit(1)
}

client.login(process.env.TOKEN)
